export type Jadwal = { a: number; b: number; map: string; tempat: string };

export type NpcDef = {
  id: string;
  nama: string;
  romansa: boolean;
  gender: "p" | "l";
  kerja: string;
  rambut: string;
  baju: string;
  kulit: string;
  topi: string;
  cinta: string[];
  suka: string[];
  tidak: string[];
  toko?: "benih" | "umum" | "warung";
  hewan?: boolean;
  pandai?: boolean;
  kades?: boolean;
  jadwal: Jadwal[];
  baru: string[];
  akrab: string[];
  dekat: string[];
  nikah: string[];
};

const H = (a: number, b: number, map: string, tempat: string): Jadwal => ({ a, b, map, tempat });

export const NPCS: NpcDef[] = [
  {
    id: "sari", nama: "Sari", romansa: true, gender: "p", kerja: "Petani sawah",
    rambut: "#3a2418", baju: "#d06a3a", kulit: "#f0c29a", topi: "caping",
    cinta: ["stroberi", "melon", "bunga"], suka: ["kangkung", "bayam", "semangka"], tidak: ["batu", "besi"],
    jadwal: [H(6, 11, "sawah", "pematang"), H(11, 14, "warung", "meja"), H(14, 18, "sawah", "pematang"), H(18, 6, "desa", "sari")],
    baru: ["Aku Sari. Sawah di timur itu sering aku garap.", "Tanah kakekmu bagus, asal jangan ditinggal kering."],
    akrab: ["Pagi ini anginnya enak buat nanam.", "Kalau kangkungmu jadi, bawalah ke pematang. Aku ingin lihat."],
    dekat: ["Aku menunggumu lewat, meski cuma sebentar.", "Ladang itu terasa kurang ramai kalau kamu tidak datang."],
    nikah: ["Aku siram yang kering tadi, sayang.", "Besok kita ke sawah bareng ya, sebelum matahari tinggi."],
  },
  {
    id: "dewi", nama: "Dewi", romansa: true, gender: "p", kerja: "Pemilik warung kopi",
    rambut: "#2a1814", baju: "#8a3048", kulit: "#e8b48a", topi: "",
    cinta: ["kopi", "gorengan", "kopisusu"], suka: ["kue", "nasi", "esjeruk"], tidak: ["batu", "belut"],
    toko: "warung",
    jadwal: [H(7, 21, "warung", "meja"), H(21, 7, "desa", "dewi")],
    baru: ["Masuk, duduk. Aku Dewi, warung ini punyaku.", "Kopinya pahit. Kalau kurang manis, bilang saja."],
    akrab: ["Hari ini yang beli gorengan sudah tiga orang. Kamu yang keempat?", "Cerita desa biasanya lebih hangat kalau ditemani kopi."],
    dekat: ["Aku simpan kursi dekat jendela untukmu.", "Kalau kamu lelah, warung ini boleh jadi rumah kedua."],
    nikah: ["Sarapan sudah aku siapkan di meja.", "Malam ini kita ngobrol pelan saja. Warungku titip ke pembantu sebentar."],
  },
  {
    id: "ayu", nama: "Ayu", romansa: true, gender: "p", kerja: "Guru sekolah desa",
    rambut: "#1c1a18", baju: "#3a5a8a", kulit: "#f2c8a4", topi: "",
    cinta: ["buahhutan", "bunga", "supsayur"], suka: ["stroberi", "madu", "jamur"], tidak: ["belut", "lele"],
    jadwal: [H(7, 12, "desa", "alun"), H(13, 17, "hutan", "dalam"), H(17, 7, "desa", "ayu")],
    baru: ["Selamat pagi. Aku Ayu, mengajar anak-anak di halaman balai.", "Hutan rimba itu buku alamku. Jangan rusak pohonnya."],
    akrab: ["Muridku bertanya siapa yang menanam di lahan tua. Aku bilang kamu.", "Sup sayur buatan sendiri lebih jujur daripada nilai ulangan."],
    dekat: ["Aku ingin menunjukkan padang bunga kalau musimnya tiba, bareng kamu.", "Kalau kamu jadi tetangga seumur hidup, aku tidak keberatan."],
    nikah: ["Aku periksa tanaman yang layu, seperti memeriksa pekerjaan rumah.", "Anak-anak desa menyapaku, dan sekarang mereka juga menyebut namamu."],
  },
  {
    id: "lestari", nama: "Lestari", romansa: true, gender: "p", kerja: "Nelayan pantai",
    rambut: "#241610", baju: "#2a6a8a", kulit: "#e0a878", topi: "bandana",
    cinta: ["kakap", "udang", "kerang"], suka: ["tongkol", "esjeruk", "nila"], tidak: ["pupuk", "batu"],
    jadwal: [H(6, 12, "sungai", "mancing"), H(12, 17, "pantai", "pasir"), H(17, 6, "desa", "lestari")],
    baru: ["Angin pantai tidak menunggu orang ragu. Aku Lestari.", "Sungai Cempaka juga punya ikan. Laut baru buka kalau jalannya aman."],
    akrab: ["Tanganmu masih halus buat petani. Nanti kapalan juga, bagus.", "Bawa kerang kalau ketemu. Aku tukar cerita ombak."],
    dekat: ["Aku berani badai, tapi gugup kalau kamu diam di sebelahku.", "Kalau suatu hari kita satu perahu, aku yang pegang dayung dulu."],
    nikah: ["Aku pulang lebih awal. Laut bisa menunggu, kamu jangan.", "Besok pagi aku bantu angkut hasil tong, lalu ke pantai."],
  },
  {
    id: "melati", nama: "Melati", romansa: true, gender: "p", kerja: "Perajin batik",
    rambut: "#3a2030", baju: "#c45a78", kulit: "#f0c0a0", topi: "kembang",
    cinta: ["bunga", "wol", "vas"], suka: ["lukisan", "stroberi", "madu"], tidak: ["batu", "lele"],
    jadwal: [H(9, 16, "hutan", "dalam"), H(16, 20, "warung", "dapur"), H(20, 9, "desa", "melati")],
    baru: ["Aku Melati. Pewarna batikku dari daun dan bunga, bukan dari toko kota.", "Jangan injak ranting kecil di hutan. Kadang itu bahan kuasku."],
    akrab: ["Wol domba yang bersih jadi motif yang halus.", "Kamu bau tanah. Anehnya aku mulai suka bau itu."],
    dekat: ["Aku ingin membatik namamu di kain, kecil saja, di sudut.", "Kalau kamu diam di pintu, cahayanya bagus buat gambar."],
    nikah: ["Vas di sudut sudah aku isi daun. Rumah jadi tidak kaku.", "Hari ini aku di rumah. Motifnya bisa menunggu, kamu tidak."],
  },
  {
    id: "kirana", nama: "Kirana", romansa: true, gender: "p", kerja: "Dokter hewan",
    rambut: "#2a2420", baju: "#3a7a62", kulit: "#e8bc98", topi: "",
    cinta: ["madu", "susu", "obat"], suka: ["telur", "rumput", "jamur"], tidak: ["gorengan", "batu"],
    jadwal: [H(8, 12, "kandangBesar", "dalam"), H(12, 16, "kandangAyam", "dalam"), H(16, 8, "desa", "kirana")],
    baru: ["Kirana. Kalau hewanmu lesu, jangan ditebak sendiri, panggil aku.", "Kandang kakekmu masih kokoh. Isinya yang perlu teman."],
    akrab: ["Hewan yang dielus tiap hari susunya lebih jujur.", "Kamu belajar cepat. Kemarin cara memegang anak ayam sudah benar."],
    dekat: ["Aku tenang kalau kamu ada di kandang, bukan cuma saat ada yang sakit.", "Rumah yang ada suaranya hewan dan orang, itu rumah yang sehat."],
    nikah: ["Aku cek hewan sebelum sarapan. Semua baik.", "Jangan lupa obat di lemari. Semoga tidak perlu, tapi siap."],
  },
  {
    id: "bima", nama: "Bima", romansa: true, gender: "l", kerja: "Peternak",
    rambut: "#1a120e", baju: "#8a6230", kulit: "#c88860", topi: "caping",
    cinta: ["jagung", "sate", "rumput"], suka: ["susu", "telur", "padi"], tidak: ["permata", "kopi"],
    hewan: true,
    jadwal: [H(6, 12, "kandangBesar", "dalam"), H(13, 17, "desa", "alun"), H(17, 6, "desa", "bima")],
    baru: ["Bima. Sapi tidak suka orang terburu. Kamu kelihatan sabar, bagus.", "Mau beli hewan, bicara ke aku. Jangan tawar-menawar sama kambingnya."],
    akrab: ["Jagung rebus dan cerita kandang, itu hari yang lengkap.", "Kandangmu mulai berbau hidup. Aku suka bau itu."],
    dekat: ["Kalau kamu jadi keluarga, hewan-hewanku ikut senang. Mereka pintar baca orang.", "Aku tidak pandai kata manis. Tapi aku ingat siapa yang membantuku angkut pakan."],
    nikah: ["Pagi ini aku beri pakan yang di pojok. Kamu urus yang depan ya.", "Duduk dulu. Kerja kandang tidak lari."],
  },
  {
    id: "andi", nama: "Andi", romansa: true, gender: "l", kerja: "Pedagang pasar",
    rambut: "#241810", baju: "#c4a03a", kulit: "#e0b090", topi: "",
    cinta: ["emas", "tomat", "permata"], suka: ["padi", "melon", "wol"], tidak: ["rumput", "batu"],
    jadwal: [H(8, 17, "pasar", "tengah"), H(17, 8, "desa", "andi")],
    baru: ["Andi. Harga di pasarku tertulis, tidak perlu bisik-bisik.", "Hasil bagus dapat harga bagus. Desa ini hidup kalau ladang hidup."],
    akrab: ["Tomatmu kemarin laku cepat. Tanam lagi kalau musimnya cocok.", "Aku hitung untung, tapi aku juga hitung siapa yang jujur."],
    dekat: ["Uang bisa dicari lagi. Orang yang aku tunggu di pintu pasar, tidak banyak.", "Kalau kita satu rumah, buku dagangku kubuat dua kolom. Satu untuk kita."],
    nikah: ["Aku pulang lebih sore. Pasar ramai, maaf.", "Taruh bon di meja. Aku yang jumlahkan nanti, jangan khawatir."],
  },
  {
    id: "rama", nama: "Rama", romansa: true, gender: "l", kerja: "Penambang dan pandai besi",
    rambut: "#14110f", baju: "#4a4a52", kulit: "#c08060", topi: "",
    cinta: ["besi", "emas", "batu"], suka: ["permata", "sate", "kopi"], tidak: ["bunga", "gorengan"],
    pandai: true,
    jadwal: [H(6, 12, "gunung", "pos"), H(12, 18, "balai", "pandai"), H(18, 6, "desa", "rama")],
    baru: ["Rama. Palu yang baik tidak berisik, orangnya juga.", "Lorong bukit berbahaya kalau terburu. Bawa stamina."],
    akrab: ["Besi yang kamu bawa cukup bersih. Terima kasih.", "Upgrade alat di balai, siang sampai sore. Pagi aku di bukit."],
    dekat: ["Aku tidak banyak bicara karena takut salah kata di depanmu.", "Kalau kamu turun tambang, pulang sebelum gelap. Aku menunggu di luar."],
    nikah: ["Alatmu sudah aku kencangkan semalam.", "Duduk. Api dapur kecil, tapi cukup untuk kita."],
  },
  {
    id: "joko", nama: "Joko", romansa: true, gender: "l", kerja: "Koki warung",
    rambut: "#2a160e", baju: "#e8e4dc", kulit: "#e8b898", topi: "",
    cinta: ["nasigoreng", "sambal", "nila"], suka: ["telur", "cabai", "udang"], tidak: ["batu", "rumput"],
    jadwal: [H(7, 14, "warung", "dapur"), H(14, 17, "pasar", "tengah"), H(17, 7, "desa", "joko")],
    baru: ["Joko, tukang masak warung Dewi. Jangan sentuh wajannya.", "Bawang merah yang segar bunyinya beda waktu digoreng."],
    akrab: ["Nasi gorengmu boleh aku coba suatu hari. Aku tidak mudah memuji.", "Ikan nila sungai, kalau bumbunya tepat, mengalahkan lauk kota."],
    dekat: ["Aku ingin masak untuk satu meja saja, bukan untuk sepuluh tamu.", "Kamu lapar? Itu alasan paling jujur untuk mampir."],
    nikah: ["Piringmu di meja. Makan sebelum dingin.", "Hari ini sambalnya sedang. Kamu tidak kuat yang kemarin, aku ingat."],
  },
  {
    id: "dimas", nama: "Dimas", romansa: true, gender: "l", kerja: "Nelayan sungai",
    rambut: "#1e1814", baju: "#3a78a0", kulit: "#d09870", topi: "bandana",
    cinta: ["esjeruk", "kembung", "kerang"], suka: ["sepat", "lele", "gorengan"], tidak: ["pupuk", "wol"],
    jadwal: [H(6, 14, "sungai", "jembatan"), H(15, 18, "pantai", "pasir"), H(18, 6, "desa", "dimas")],
    baru: ["Dimas. Sungai ini kenal aku sejak kecil, jadi dia tidak nakal ke aku.", "Pancing yang senarnya kusut itu bukan alat, itu hiasan."],
    akrab: ["Es jeruk setelah tiga ikan gagal, rasanya jadi filosofi.", "Kamu mulai bisa membaca riak. Aku bangga, dikit."],
    dekat: ["Kalau kita satu rumah, aku janji tidak membawa lumpur ke tikar. Sering.", "Aku suka kamu yang tidak tertawa saat ikanku lepas."],
    nikah: ["Aku taruh ikan di tong. Yang bagus, bukan yang malu-malu.", "Sore ini aku di rumah. Sungai tidak akan kabur."],
  },
  {
    id: "farhan", nama: "Farhan", romansa: true, gender: "l", kerja: "Pegawai balai desa",
    rambut: "#241c16", baju: "#f2f0ea", kulit: "#e0b498", topi: "",
    cinta: ["kopi", "supsayur", "bunga"], suka: ["nasi", "buahhutan", "kue"], tidak: ["belut", "batu"],
    jadwal: [H(8, 16, "balai", "samping"), H(16, 8, "desa", "farhan")],
    baru: ["Farhan, pegawai balai. Surat dan jadwal festival lewat mejaku.", "Kalau ada acara, papan di balai lebih akurat daripada gosip warung."],
    akrab: ["Aku dulu kaku. Desa ini mengajari aku cara tersenyum tanpa formulir.", "Kopimu, eh, kopi untukku, terima kasih. Itu sudah tercatat di hati, bukan di buku."],
    dekat: ["Aku ingin pulang bukan ke mess, tapi ke rumah yang lampunya kamu nyalakan.", "Kalau kamu mau, aku urus surat nikahnya rapi. Tapi kata-katanya tetap dari kita."],
    nikah: ["Jadwal desa hari ini sepi. Aku bisa di rumah sampai siang.", "Jangan lupa kalender. Aku tempel yang kecil di dinding."],
  },
  {
    id: "sutopo", nama: "Pak Kades Sutopo", romansa: false, gender: "l", kerja: "Kepala desa",
    rambut: "#6a6a6a", baju: "#6a3a4a", kulit: "#c89878", topi: "peci",
    cinta: ["nasi", "kopi", "buahhutan"], suka: ["padi", "kue", "susu"], tidak: ["belut"],
    kades: true,
    jadwal: [H(8, 18, "balai", "meja"), H(18, 8, "desa", "sutopo")],
    baru: ["Selamat datang di Sukamaju. Aku Sutopo. Lahan Harso aman di tanganmu, nak.", "Kalau ada festival, datang ke aku. Jangan cuma dengar dari gorengan."],
    akrab: ["Desa ini kecil, jadi kebaikan juga cepat kelihatan.", "Kakekmu dulu menanam lebih banyak dari yang dia jual. Itu yang bikin kami kenyang."],
    dekat: ["Kamu sudah jadi warga, bukan tamu.", "Urus keluarga baik-baik. Desa mengawasi dengan cara yang baik."],
    nikah: [],
  },
  {
    id: "sumi", nama: "Nenek Sumi", romansa: false, gender: "p", kerja: "Pemilik toko",
    rambut: "#d0d0d0", baju: "#7a3a4a", kulit: "#e0b090", topi: "",
    cinta: ["gorengan", "telur", "bunga"], suka: ["kue", "kopi", "bayam"], tidak: ["besi"],
    toko: "umum",
    jadwal: [H(7, 17, "pasar", "umum"), H(17, 7, "pasar", "belakang")],
    baru: ["Sumi, nak. Toko ini lengkap, asal kamu bilang mau apa dengan sopan.", "Pupuk, pakan, obat, cincin, semua ada. Cincin jangan dibeli main-main."],
    akrab: ["Kamu sudah langganan. Nenek kasih senyum, bukan diskon. Disiplin.", "Bawa bunga sekali-kali. Nenek juga ingin dipandang."],
    dekat: ["Hati-hati di tambang. Nenek tidak mau kehilangan pelanggan tetap.", "Kalau menikah, undang nenek. Aku bawa gorengan, bukan pidato."],
    nikah: [],
  },
  {
    id: "darma", nama: "Pak Darma", romansa: false, gender: "l", kerja: "Penjual benih",
    rambut: "#3a3028", baju: "#5a7a3a", kulit: "#c89070", topi: "caping",
    cinta: ["padi", "jagung", "pupuk"], suka: ["kangkung", "tomat", "wortel"], tidak: ["permata"],
    toko: "benih",
    jadwal: [H(7, 16, "pasar", "benih"), H(16, 7, "desa", "darma")],
    baru: ["Darma. Benih yang kual sesuai musim. Jangan memaksa stroberi saat kemarau panjang.", "Baca tanah. Tanah yang dicangkul tapi tidak disiram itu cuma debu rapi."],
    akrab: ["Ladangmu mulai rapi. Kakekmu pasti diam-diam bangga.", "Kalau musim berganti, jual yang tersisa sebelum layu. Jangan nekad."],
    dekat: ["Kamu sudah petani, bukan orang kota yang main tanah.", "Benih langka kutitipkan kalau kamu janji tidak disia-siakan."],
    nikah: [],
  },
];

export const NPC_MAP = Object.fromEntries(NPCS.map((n) => [n.id, n]));
