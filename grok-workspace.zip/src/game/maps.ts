export type Portal = { x: number; y: number; ke: string; tx: number; ty: number; kunci?: "pantai" | "gunung" };

export type Peta = {
  id: string;
  nama: string;
  w: number;
  h: number;
  tiles: string[][];
  portal: Portal[];
  jangkar: Record<string, { x: number; y: number }>;
  luar: boolean;
};

export const PADAT = new Set(["f", "t", "r", "h", "o", "m", "#", "B", "E", "C", "b", "K", "U", "X", "w", "W"]);

export function padat(ch: string) {
  return PADAT.has(ch);
}

export function ambil(tiles: string[][], x: number, y: number) {
  if (y < 0 || x < 0 || y >= tiles.length || x >= tiles[0].length) return "#";
  return tiles[y][x];
}

function grid(w: number, h: number, isi: string) {
  return Array.from({ length: h }, () => Array(w).fill(isi));
}

function isi(t: string[][], x: number, y: number, w: number, h: number, ch: string) {
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) if (t[y + j] && t[y + j][x + i] !== undefined) t[y + j][x + i] = ch;
}

function bangunan(t: string[][], x: number, y: number, w: number, h: number) {
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) t[y + j][x + i] = j < 2 ? "o" : "h";
  const dx = x + (w >> 1);
  const dy = y + h - 1;
  t[dy][dx] = "+";
  if (t[dy + 1]) t[dy + 1][dx] = "d";
  return { x: dx, y: dy };
}

function pagar(t: string[][]) {
  const h = t.length;
  const w = t[0].length;
  for (let x = 0; x < w; x++) {
    t[0][x] = "f";
    t[h - 1][x] = "f";
  }
  for (let y = 0; y < h; y++) {
    t[y][0] = "f";
    t[y][w - 1] = "f";
  }
}

function pohon(t: string[][], n: number, seed: number) {
  let s = seed >>> 0;
  let c = 0;
  const h = t.length;
  const w = t[0].length;
  for (let k = 0; k < 800 && c < n; k++) {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    const x = 1 + (s % (w - 2));
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    const y = 1 + (s % (h - 2));
    if (t[y][x] === "g") {
      t[y][x] = "t";
      c++;
    }
  }
}

function jalur(t: string[][], x0: number, y0: number, x1: number, y1: number) {
  let x = x0;
  let y = y0;
  const langkah = Math.abs(x1 - x0) + Math.abs(y1 - y0) + 2;
  for (let i = 0; i < langkah; i++) {
    if (t[y] && t[y][x] !== undefined && !"ho+fmwW#".includes(t[y][x])) t[y][x] = t[y][x] === "s" ? "s" : "d";
    if (x !== x1) x += Math.sign(x1 - x);
    else if (y !== y1) y += Math.sign(y1 - y);
    else break;
  }
}

export const PETAS: Record<string, Peta> = {};

function daftar(p: Peta) {
  PETAS[p.id] = p;
  return p;
}

function buatLadang() {
  const w = 34;
  const h = 24;
  const t = grid(w, h, "g");
  pagar(t);
  const rumah = bangunan(t, 2, 1, 7, 5);
  const ayam = bangunan(t, 18, 1, 5, 4);
  const sapi = bangunan(t, 25, 1, 6, 4);
  isi(t, 9, 8, 16, 8, "s");
  for (let x = 2; x < w - 1; x++) if (t[7][x] === "g" || t[7][x] === "f") t[7][x] = "d";
  for (let y = 7; y < h - 1; y++) if (t[y][8] === "g" || t[y][8] === "s") t[y][8] = "d";
  for (let x = 2; x < w - 1; x++) if (t[17][x] === "g" || t[17][x] === "s") t[17][x] = "d";
  for (let x = 24; x < w - 1; x++) if (t[12][x] !== "h" && t[12][x] !== "o" && t[12][x] !== "+") t[12][x] = "d";
  for (let x = 1; x < 9; x++) if (t[12][x] !== "h" && t[12][x] !== "o") t[12][x] = "d";
  t[9][4] = "E";
  t[7][12] = "B";
  t[h - 1][17] = "d";
  t[12][0] = "d";
  t[12][w - 1] = "d";
  for (let x = 3; x < 8; x++) if (t[19][x] === "g") t[19][x] = "G";
  for (let x = 26; x < 32; x++) if (t[20][x] === "g") t[20][x] = "G";
  pohon(t, 8, 3);
  const jangkar = {
    tengah: { x: 16, y: 12 },
    sumur: { x: 4, y: 10 },
    jalan: { x: 17, y: 18 },
    depanAyam: { x: ayam.x, y: ayam.y + 1 },
    depanSapi: { x: sapi.x, y: sapi.y + 1 },
    depanRumah: { x: rumah.x, y: rumah.y + 1 },
  };
  const portal: Portal[] = [
    { x: rumah.x, y: rumah.y, ke: "rumah", tx: 8, ty: 2 },
    { x: ayam.x, y: ayam.y, ke: "kandangAyam", tx: 7, ty: 2 },
    { x: sapi.x, y: sapi.y, ke: "kandangBesar", tx: 8, ty: 2 },
    { x: 17, y: h - 1, ke: "desa", tx: 20, ty: 1 },
    { x: 0, y: 12, ke: "sungai", tx: 26, ty: 10 },
    { x: w - 1, y: 12, ke: "sawah", tx: 1, ty: 10 },
  ];
  return {
    peta: daftar({ id: "ladang", nama: "Ladang Warisan", w, h, tiles: t, portal, jangkar, luar: true }),
    rumah,
    ayam,
    sapi,
  };
}

function interior(
  id: string,
  nama: string,
  w: number,
  h: number,
  keluar: { x: number; y: number },
  props: (t: string[][], j: Record<string, { x: number; y: number }>) => void,
) {
  const t = grid(w, h, ".");
  for (let x = 0; x < w; x++) {
    t[0][x] = "#";
    t[h - 1][x] = "#";
  }
  for (let y = 0; y < h; y++) {
    t[y][0] = "#";
    t[y][w - 1] = "#";
  }
  const dx = (w / 2) | 0;
  t[0][dx] = "+";
  const jangkar: Record<string, { x: number; y: number }> = {
    tengah: { x: dx, y: 5 },
    dalam: { x: dx, y: 4 },
  };
  props(t, jangkar);
  const portal: Portal[] = [{ x: dx, y: 0, ke: "ladang", tx: keluar.x, ty: keluar.y + 1 }];
  daftar({ id, nama, w, h, tiles: t, portal, jangkar, luar: false });
}

function buatDesa() {
  const w = 42;
  const h = 28;
  const t = grid(w, h, "g");
  for (let x = 0; x < w; x++) {
    t[0][x] = "t";
    t[h - 1][x] = "t";
  }
  for (let y = 0; y < h; y++) {
    t[y][0] = "t";
    t[y][w - 1] = "t";
  }
  for (let x = 1; x < w - 1; x++) t[9][x] = "d";
  for (let y = 1; y < h - 1; y++) if (t[y][20] === "g" || t[y][20] === "t") t[y][20] = "d";
  for (let y = 1; y <= 9; y++) t[y][36] = "d";
  t[0][20] = "d";
  t[h - 1][20] = "d";
  t[9][0] = "d";
  t[9][w - 1] = "d";
  t[0][36] = "d";
  const balai = bangunan(t, 2, 2, 8, 6);
  const warung = bangunan(t, 12, 2, 7, 5);
  const praktik = bangunan(t, 22, 2, 6, 5);
  const kades = bangunan(t, 30, 2, 5, 4);
  const rumahX = [2, 8, 14, 24, 30, 36];
  const atas = rumahX.map((x) => bangunan(t, x, 12, 5, 4));
  const bawah = rumahX.map((x) => bangunan(t, x, 20, 5, 4));
  const namaAtas = ["sari", "dewi", "ayu", "lestari", "melati", "kirana"];
  const namaBawah = ["bima", "andi", "rama", "joko", "dimas", "farhan"];
  const jangkar: Record<string, { x: number; y: number }> = {
    alun: { x: 16, y: 10 },
    depanBalai: { x: balai.x, y: balai.y + 1 },
    depanWarung: { x: warung.x, y: warung.y + 1 },
    depanPraktik: { x: praktik.x, y: praktik.y + 1 },
    sutopo: { x: kades.x, y: kades.y + 1 },
    darma: { x: 11, y: 10 },
  };
  namaAtas.forEach((n, i) => {
    jangkar[n] = { x: atas[i].x, y: atas[i].y + 1 };
  });
  namaBawah.forEach((n, i) => {
    jangkar[n] = { x: bawah[i].x, y: bawah[i].y + 1 };
  });
  t[10][16] = "d";
  pohon(t, 10, 9);
  const portal: Portal[] = [
    { x: 20, y: 0, ke: "ladang", tx: 17, ty: 22 },
    { x: 20, y: h - 1, ke: "pantai", tx: 15, ty: 1, kunci: "pantai" },
    { x: 0, y: 9, ke: "hutan", tx: 21, ty: 10 },
    { x: w - 1, y: 9, ke: "pasar", tx: 1, ty: 9 },
    { x: 36, y: 0, ke: "gunung", tx: 12, ty: 15, kunci: "gunung" },
    { x: balai.x, y: balai.y, ke: "balai", tx: 7, ty: 2 },
    { x: warung.x, y: warung.y, ke: "warung", tx: 6, ty: 2 },
  ];
  daftar({ id: "desa", nama: "Desa Sukamaju", w, h, tiles: t, portal, jangkar, luar: true });
  return { balai, warung };
}

function buatLain() {
  const sungaiT = grid(28, 20, "g");
  pagar(sungaiT);
  isi(sungaiT, 8, 2, 12, 16, "w");
  for (let y = 8; y <= 11; y++) for (let x = 6; x <= 20; x++) sungaiT[y][x] = "~";
  sungaiT[10][0] = "d";
  sungaiT[10][27] = "d";
  for (let x = 1; x < 8; x++) sungaiT[10][x] = "d";
  for (let x = 20; x < 27; x++) sungaiT[10][x] = "d";
  sungaiT[6][4] = "*";
  sungaiT[14][5] = "*";
  daftar({
    id: "sungai",
    nama: "Sungai Cempaka",
    w: 28,
    h: 20,
    tiles: sungaiT,
    portal: [{ x: 27, y: 10, ke: "ladang", tx: 1, ty: 12 }],
    jangkar: { jembatan: { x: 14, y: 10 }, mancing: { x: 6, y: 8 }, tepi: { x: 5, y: 14 } },
    luar: true,
  });

  const pantai = grid(30, 18, "n");
  for (let y = 11; y < 18; y++) for (let x = 0; x < 30; x++) pantai[y][x] = "W";
  for (let x = 0; x < 30; x++) pantai[0][x] = "t";
  pantai[0][15] = "d";
  pantai[1][15] = "n";
  pantai[4][6] = "*";
  pantai[5][20] = "*";
  pantai[8][10] = "*";
  daftar({
    id: "pantai",
    nama: "Pantai Kelapa",
    w: 30,
    h: 18,
    tiles: pantai,
    portal: [{ x: 15, y: 0, ke: "desa", tx: 20, ty: 26 }],
    jangkar: { pasir: { x: 15, y: 6 }, laut: { x: 18, y: 9 }, utara: { x: 15, y: 2 } },
    luar: true,
  });

  const gunung = grid(24, 18, "g");
  for (let x = 0; x < 24; x++) {
    gunung[0][x] = "m";
    gunung[17][x] = "m";
  }
  for (let y = 0; y < 18; y++) {
    gunung[y][0] = "m";
    gunung[y][23] = "m";
  }
  for (let y = 1; y < 17; y++) gunung[y][12] = "d";
  gunung[17][12] = "d";
  gunung[4][12] = "+";
  gunung[3][11] = "r";
  gunung[3][13] = "r";
  gunung[6][8] = "r";
  gunung[8][16] = "r";
  daftar({
    id: "gunung",
    nama: "Bukit Wijaya",
    w: 24,
    h: 18,
    tiles: gunung,
    portal: [
      { x: 12, y: 17, ke: "desa", tx: 36, ty: 1 },
      { x: 12, y: 4, ke: "tambang", tx: 10, ty: 12 },
    ],
    jangkar: { pos: { x: 12, y: 8 }, depanGua: { x: 12, y: 6 } },
    luar: true,
  });

  const hutan = grid(24, 20, "g");
  for (let x = 0; x < 24; x++) {
    hutan[0][x] = "t";
    hutan[19][x] = "t";
  }
  for (let y = 0; y < 20; y++) {
    hutan[y][0] = "t";
    hutan[y][23] = "t";
  }
  for (let x = 1; x < 23; x++) hutan[10][x] = "d";
  hutan[10][23] = "d";
  pohon(hutan, 28, 21);
  hutan[6][8] = "E";
  hutan[5][8] = "d";
  hutan[7][6] = "*";
  hutan[8][14] = "*";
  hutan[12][7] = "*";
  hutan[13][16] = "*";
  hutan[4][16] = "*";
  daftar({
    id: "hutan",
    nama: "Hutan Rimba",
    w: 24,
    h: 20,
    tiles: hutan,
    portal: [{ x: 23, y: 10, ke: "desa", tx: 1, ty: 9 }],
    jangkar: { dalam: { x: 8, y: 10 }, air: { x: 8, y: 5 } },
    luar: true,
  });

  const sawah = grid(26, 18, "g");
  pagar(sawah);
  isi(sawah, 4, 3, 18, 10, "=");
  for (let y = 3; y < 14; y += 3) for (let x = 4; x < 22; x++) sawah[y][x] = "d";
  for (let y = 1; y < 17; y++) sawah[y][2] = "d";
  sawah[10][0] = "d";
  sawah[8][18] = "w";
  sawah[8][19] = "w";
  sawah[9][18] = "w";
  sawah[9][19] = "w";
  bangunan(sawah, 18, 12, 5, 4);
  sawah[6][8] = "*";
  sawah[10][12] = "*";
  daftar({
    id: "sawah",
    nama: "Sawah Hijau",
    w: 26,
    h: 18,
    tiles: sawah,
    portal: [{ x: 0, y: 10, ke: "ladang", tx: 32, ty: 12 }],
    jangkar: { pematang: { x: 10, y: 6 }, gubuk: { x: 20, y: 16 } },
    luar: true,
  });

  const pasar = grid(26, 18, "d");
  for (let x = 0; x < 26; x++) {
    pasar[0][x] = "f";
    pasar[17][x] = "f";
  }
  for (let y = 0; y < 18; y++) {
    pasar[y][0] = "f";
    pasar[y][25] = "f";
  }
  pasar[9][0] = "d";
  isi(pasar, 4, 3, 6, 2, "K");
  isi(pasar, 14, 3, 6, 2, "K");
  isi(pasar, 8, 12, 8, 2, "K");
  for (let x = 3; x < 22; x++) pasar[8][x] = "d";
  daftar({
    id: "pasar",
    nama: "Pasar Pagi",
    w: 26,
    h: 18,
    tiles: pasar,
    portal: [{ x: 0, y: 9, ke: "desa", tx: 40, ty: 9 }],
    jangkar: { benih: { x: 6, y: 6 }, umum: { x: 16, y: 6 }, tengah: { x: 12, y: 10 }, belakang: { x: 20, y: 14 } },
    luar: true,
  });

  const balaiT = grid(16, 11, ".");
  for (let x = 0; x < 16; x++) {
    balaiT[0][x] = "#";
    balaiT[10][x] = "#";
  }
  for (let y = 0; y < 11; y++) {
    balaiT[y][0] = "#";
    balaiT[y][15] = "#";
  }
  balaiT[0][7] = "+";
  balaiT[3][4] = "K";
  balaiT[3][11] = "K";
  daftar({
    id: "balai",
    nama: "Balai Desa",
    w: 16,
    h: 11,
    tiles: balaiT,
    portal: [{ x: 7, y: 0, ke: "desa", tx: 6, ty: 8 }],
    jangkar: { meja: { x: 4, y: 5 }, samping: { x: 8, y: 6 }, pandai: { x: 11, y: 5 }, tengah: { x: 7, y: 7 } },
    luar: false,
  });

  const warungT = grid(14, 10, ".");
  for (let x = 0; x < 14; x++) {
    warungT[0][x] = "#";
    warungT[9][x] = "#";
  }
  for (let y = 0; y < 10; y++) {
    warungT[y][0] = "#";
    warungT[y][13] = "#";
  }
  warungT[0][6] = "+";
  warungT[3][3] = "K";
  warungT[3][4] = "K";
  warungT[3][10] = "K";
  daftar({
    id: "warung",
    nama: "Warung Kopi Melati",
    w: 14,
    h: 10,
    tiles: warungT,
    portal: [{ x: 6, y: 0, ke: "desa", tx: 15, ty: 7 }],
    jangkar: { meja: { x: 4, y: 5 }, dapur: { x: 10, y: 5 }, tengah: { x: 6, y: 6 } },
    luar: false,
  });
}

function buatRumah(depan: { x: number; y: number }) {
  const w = 16;
  const h = 12;
  const t = grid(w, h, ".");
  for (let x = 0; x < w; x++) {
    t[0][x] = "#";
    t[h - 1][x] = "#";
  }
  for (let y = 0; y < h; y++) {
    t[y][0] = "#";
    t[y][w - 1] = "#";
  }
  t[0][8] = "+";
  t[2][2] = "b";
  t[2][3] = "b";
  t[2][5] = "C";
  t[2][11] = "K";
  t[2][12] = "K";
  daftar({
    id: "rumah",
    nama: "Rumah Kayu",
    w,
    h,
    tiles: t,
    portal: [{ x: 8, y: 0, ke: "ladang", tx: depan.x, ty: depan.y + 1 }],
    jangkar: {
      tengah: { x: 8, y: 6 },
      dapur: { x: 11, y: 4 },
      sisi: { x: 3, y: 4 },
      anak: { x: 12, y: 8 },
      kasur: { x: 3, y: 4 },
    },
    luar: false,
  });
}

function buatKandang(id: string, nama: string, w: number, depan: { x: number; y: number }, keranjang: boolean) {
  const h = 11;
  const t = grid(w, h, ",");
  for (let x = 0; x < w; x++) {
    t[0][x] = "#";
    t[h - 1][x] = "#";
  }
  for (let y = 0; y < h; y++) {
    t[y][0] = "#";
    t[y][w - 1] = "#";
  }
  const dx = (w / 2) | 0;
  t[0][dx] = "+";
  if (keranjang) t[2][2] = "V";
  else t[2][2] = "V";
  for (let x = 2; x < w - 2; x += 3) {
    t[4][x] = "f";
    t[7][x] = "f";
  }
  daftar({
    id,
    nama,
    w,
    h,
    tiles: t,
    portal: [{ x: dx, y: 0, ke: "ladang", tx: depan.x, ty: depan.y + 1 }],
    jangkar: { dalam: { x: dx, y: 5 }, keranjang: { x: 3, y: 3 }, tengah: { x: dx, y: 8 } },
    luar: false,
  });
}

const ladang = buatLadang();
buatRumah(ladang.rumah);
buatKandang("kandangAyam", "Kandang Unggas", 14, ladang.ayam, true);
buatKandang("kandangBesar", "Kandang Ternak", 16, ladang.sapi, true);
buatDesa();
buatLain();

const LUAR = new Set(["ladang", "desa", "pasar", "sungai", "pantai", "gunung", "hutan", "sawah"]);
export function petaLuar(id: string) {
  return LUAR.has(id);
}

export function periksaPeta() {
  const masalah: string[] = [];
  for (const p of Object.values(PETAS)) {
    for (const po of p.portal) {
      const ch = p.tiles[po.y]?.[po.x];
      if (ch === undefined) masalah.push(p.id + " portal luar " + po.x + "," + po.y);
      else if (padat(ch)) masalah.push(p.id + " portal padat " + ch + " " + po.x + "," + po.y);
      if (po.ke === "tambang") continue;
      const dest = PETAS[po.ke];
      if (!dest) {
        masalah.push("tidak ada peta " + po.ke);
        continue;
      }
      const dch = dest.tiles[po.ty]?.[po.tx];
      if (dch === undefined || padat(dch)) masalah.push(p.id + " tujuan buruk ke " + po.ke + " " + dch);
      if (dest.portal.some((q) => q.x === po.tx && q.y === po.ty)) masalah.push(p.id + " tujuan adalah portal");
    }
    for (const [k, a] of Object.entries(p.jangkar)) {
      const ch = p.tiles[a.y]?.[a.x];
      if (!ch || padat(ch)) masalah.push("jangkar " + p.id + "." + k + " " + ch);
      if (p.portal.some((q) => q.x === a.x && q.y === a.y)) masalah.push("jangkar di portal " + p.id + "." + k);
    }
  }
  return masalah;
}

export function buatTambang(lantai: number, biji: number) {
  const w = 20;
  const h = 16;
  const t = grid(w, h, "m");
  let s = (biji + lantai * 997) >>> 0;
  const rnd = () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s;
  };
  for (let y = 2; y <= 14; y++) t[y][10] = "u";
  let x = 10;
  let y = 12;
  for (let i = 0; i < 160; i++) {
    const d = rnd() % 4;
    const dx = d === 0 ? 1 : d === 1 ? -1 : 0;
    const dy = d === 2 ? 1 : d === 3 ? -1 : 0;
    x = Math.max(1, Math.min(w - 2, x + dx));
    y = Math.max(1, Math.min(h - 2, y + dy));
    t[y][x] = rnd() % (4 + Math.floor(lantai / 3)) === 0 ? "U" : "u";
  }
  for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) t[13 + j][10 + i] = "u";
  t[14][10] = "L";
  t[2][10] = "l";
  for (let i = 0; i < 6 + lantai; i++) {
    const ox = 1 + (rnd() % (w - 2));
    const oy = 1 + (rnd() % (h - 2));
    if (t[oy][ox] === "u") t[oy][ox] = "U";
  }
  return t;
}
