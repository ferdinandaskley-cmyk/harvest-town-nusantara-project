import type { Musim } from "./types";

export type Tanaman = {
  id: string;
  nama: string;
  benih: number;
  jual: number;
  hari: number;
  musim: Musim[];
  hasil: number;
  warna: string;
};

export const TANAMAN: Tanaman[] = [
  { id: "padi", nama: "Padi", benih: 50, jual: 160, hari: 7, musim: ["hujan", "panen"], hasil: 1, warna: "#e6d36a" },
  { id: "cabai", nama: "Cabai", benih: 40, jual: 90, hari: 5, musim: ["kemarau", "panen"], hasil: 2, warna: "#d23a2a" },
  { id: "tomat", nama: "Tomat", benih: 60, jual: 160, hari: 6, musim: ["kemarau", "bunga"], hasil: 1, warna: "#e24b3a" },
  { id: "jagung", nama: "Jagung", benih: 70, jual: 200, hari: 7, musim: ["kemarau", "panen"], hasil: 1, warna: "#f0d056" },
  { id: "terong", nama: "Terong", benih: 50, jual: 150, hari: 6, musim: ["hujan", "bunga"], hasil: 1, warna: "#6a3a86" },
  { id: "wortel", nama: "Wortel", benih: 40, jual: 130, hari: 5, musim: ["bunga", "kemarau"], hasil: 1, warna: "#e88830" },
  { id: "kentang", nama: "Kentang", benih: 50, jual: 150, hari: 6, musim: ["bunga", "hujan"], hasil: 1, warna: "#c4a06a" },
  { id: "kangkung", nama: "Kangkung", benih: 30, jual: 70, hari: 3, musim: ["hujan", "panen"], hasil: 2, warna: "#3aaa48" },
  { id: "bayam", nama: "Bayam", benih: 30, jual: 70, hari: 3, musim: ["hujan", "bunga"], hasil: 2, warna: "#2e8a38" },
  { id: "stroberi", nama: "Stroberi", benih: 80, jual: 140, hari: 8, musim: ["bunga"], hasil: 3, warna: "#e23a4a" },
  { id: "semangka", nama: "Semangka", benih: 100, jual: 360, hari: 10, musim: ["kemarau"], hasil: 1, warna: "#d84a5a" },
  { id: "melon", nama: "Melon", benih: 110, jual: 390, hari: 10, musim: ["kemarau", "bunga"], hasil: 1, warna: "#d8d06a" },
  { id: "bawangmerah", nama: "Bawang Merah", benih: 45, jual: 140, hari: 5, musim: ["kemarau", "panen"], hasil: 1, warna: "#c4546a" },
  { id: "bawangputih", nama: "Bawang Putih", benih: 45, jual: 150, hari: 6, musim: ["bunga", "kemarau"], hasil: 1, warna: "#f2efe4" },
  { id: "kacang", nama: "Kacang Panjang", benih: 40, jual: 100, hari: 5, musim: ["hujan", "panen"], hasil: 2, warna: "#6aaa40" },
];

export const TANAMAN_MAP = Object.fromEntries(TANAMAN.map((t) => [t.id, t]));

export type ItemDef = {
  id: string;
  nama: string;
  kat: "benih" | "panen" | "hasil" | "makan" | "bahan" | "hadiah" | "dekor" | "lain";
  jual: number;
  beli?: number;
  stamina?: number;
  deskripsi: string;
  tanam?: string;
};

export const ITEM: Record<string, ItemDef> = {};

for (const t of TANAMAN) {
  ITEM["benih_" + t.id] = {
    id: "benih_" + t.id,
    nama: "Benih " + t.nama,
    kat: "benih",
    jual: Math.floor(t.benih / 2),
    beli: t.benih,
    deskripsi: "Benih " + t.nama + ". Siap panen dalam " + t.hari + " hari kalau disiram.",
    tanam: t.id,
  };
  ITEM[t.id] = {
    id: t.id,
    nama: t.nama,
    kat: "panen",
    jual: t.jual,
    deskripsi: t.nama + " segar dari ladang Desa Sukamaju.",
  };
}

function lain(d: ItemDef) {
  ITEM[d.id] = d;
}

lain({ id: "telur", nama: "Telur Ayam", kat: "hasil", jual: 70, deskripsi: "Telur hangat dari kandang." });
lain({ id: "telurbebek", nama: "Telur Bebek", kat: "hasil", jual: 100, deskripsi: "Telur bebek, enak buat nasi goreng." });
lain({ id: "susu", nama: "Susu Sapi", kat: "hasil", jual: 220, deskripsi: "Susu sapi pagi hari." });
lain({ id: "susukambing", nama: "Susu Kambing", kat: "hasil", jual: 180, deskripsi: "Susu kambing yang gurih." });
lain({ id: "wol", nama: "Wol Domba", kat: "hasil", jual: 420, deskripsi: "Wol lembut, bagus buat kerajinan." });
lain({ id: "pakan", nama: "Pakan Ternak", kat: "lain", jual: 5, beli: 20, deskripsi: "Pakan harian ayam, bebek, sapi, kambing, dan domba." });
lain({ id: "pupuk", nama: "Pupuk Kandang", kat: "lain", jual: 20, beli: 80, deskripsi: "Bikin tanaman tumbuh lebih cepat dan harga jual naik." });
lain({ id: "obat", nama: "Obat Ternak", kat: "lain", jual: 40, beli: 180, deskripsi: "Untuk hewan yang sakit karena lupa dikasih makan." });
lain({ id: "rumput", nama: "Rumput", kat: "lain", jual: 5, deskripsi: "Rumput potongan. Bisa jadi pakan." });
lain({ id: "cincin", nama: "Cincin Janji", kat: "hadiah", jual: 500, beli: 3000, deskripsi: "Cincin sederhana untuk melamar seseorang yang hatinya sudah dekat." });
lain({ id: "batu", nama: "Batu", kat: "bahan", jual: 10, deskripsi: "Batu dari bukit. Bahan upgrade." });
lain({ id: "besi", nama: "Besi", kat: "bahan", jual: 40, deskripsi: "Bijih besi. Rama bisa menempanya." });
lain({ id: "emas", nama: "Emas", kat: "bahan", jual: 120, deskripsi: "Emas berkilau dari lorong dalam." });
lain({ id: "permata", nama: "Permata", kat: "bahan", jual: 400, deskripsi: "Permata langka dari dasar tambang." });
lain({ id: "nasi", nama: "Nasi Campur", kat: "makan", jual: 30, beli: 80, stamina: 35, deskripsi: "Nasi campur warung. Mengisi tenaga." });
lain({ id: "kopi", nama: "Kopi Tubruk", kat: "makan", jual: 15, beli: 40, stamina: 18, deskripsi: "Kopi pahit hangat. Bisa diminum atau dibuat kopi susu." });
lain({ id: "gorengan", nama: "Gorengan", kat: "makan", jual: 10, beli: 30, stamina: 14, deskripsi: "Gorengan renyah teman ngobrol." });
lain({ id: "sate", nama: "Sate Desa", kat: "makan", jual: 40, beli: 110, stamina: 45, deskripsi: "Sate bumbu kacang. Mengenyangkan." });
lain({ id: "esjeruk", nama: "Es Jeruk", kat: "makan", jual: 15, beli: 45, stamina: 20, deskripsi: "Segar habis di pantai." });
lain({ id: "nasigoreng", nama: "Nasi Goreng", kat: "makan", jual: 90, stamina: 50, deskripsi: "Nasi goreng telur buatan sendiri." });
lain({ id: "sambal", nama: "Sambal Desa", kat: "makan", jual: 70, stamina: 12, deskripsi: "Sambal pedas. Hadiah yang berani." });
lain({ id: "supsayur", nama: "Sup Sayur", kat: "makan", jual: 120, stamina: 55, deskripsi: "Sup hangat wortel, kentang, dan bayam." });
lain({ id: "jussemangka", nama: "Jus Semangka", kat: "makan", jual: 140, stamina: 40, deskripsi: "Jus semangka dingin." });
lain({ id: "kopisusu", nama: "Kopi Susu", kat: "makan", jual: 100, stamina: 40, deskripsi: "Kopi susu manis, favorit warung." });
lain({ id: "jamur", nama: "Jamur Hutan", kat: "hadiah", jual: 30, deskripsi: "Jamur dari rimba. Bisa dijual atau dihadiahkan." });
lain({ id: "bambu", nama: "Bambu", kat: "bahan", jual: 25, deskripsi: "Batang bambu muda." });
lain({ id: "madu", nama: "Madu Hutan", kat: "hadiah", jual: 80, deskripsi: "Madu liar. Kirana suka ini." });
lain({ id: "buahhutan", nama: "Buah Hutan", kat: "hadiah", jual: 40, deskripsi: "Buah asam manis dari pohon rimba." });
lain({ id: "kerang", nama: "Kerang", kat: "hadiah", jual: 35, deskripsi: "Kerang pantai." });
lain({ id: "bunga", nama: "Bunga Melati", kat: "hadiah", jual: 20, beli: 60, deskripsi: "Bunga sederhana. Banyak warga suka." });
lain({ id: "tikar", nama: "Tikar Anyam", kat: "dekor", jual: 40, beli: 200, deskripsi: "Tikar untuk lantai rumah." });
lain({ id: "vas", nama: "Vas Gerabah", kat: "dekor", jual: 60, beli: 350, deskripsi: "Vas tanah liat." });
lain({ id: "lampu", nama: "Lampu Teplok", kat: "dekor", jual: 70, beli: 400, deskripsi: "Lampu minyak untuk malam." });
lain({ id: "lukisan", nama: "Lukisan Sawah", kat: "dekor", jual: 100, beli: 600, deskripsi: "Lukisan pematang sawah." });
lain({ id: "bendera", nama: "Bendera Kecil", kat: "dekor", jual: 50, deskripsi: "Bendera dari festival kemerdekaan." });
lain({ id: "kue", nama: "Kue Tahun Baru", kat: "makan", jual: 40, stamina: 30, deskripsi: "Kue manis dari malam tahun baru." });

export type HewanDef = {
  id: string;
  nama: string;
  harga: number;
  kandang: "ayam" | "besar";
  produk: string;
  hari: number;
  kunci: boolean;
  warna: string;
};

export const HEWAN: Record<string, HewanDef> = {
  ayam: { id: "ayam", nama: "Ayam", harga: 1200, kandang: "ayam", produk: "telur", hari: 1, kunci: false, warna: "#f2efe6" },
  bebek: { id: "bebek", nama: "Bebek", harga: 1800, kandang: "ayam", produk: "telurbebek", hari: 1, kunci: false, warna: "#f0e27a" },
  kambing: { id: "kambing", nama: "Kambing", harga: 4200, kandang: "besar", produk: "susukambing", hari: 1, kunci: false, warna: "#d9d3c8" },
  sapi: { id: "sapi", nama: "Sapi", harga: 6500, kandang: "besar", produk: "susu", hari: 1, kunci: true, warna: "#f7f4ee" },
  domba: { id: "domba", nama: "Domba", harga: 4800, kandang: "besar", produk: "wol", hari: 4, kunci: true, warna: "#f4f1ea" },
};

export type IkanDef = { id: string; nama: string; jual: number; tempat: "sungai" | "laut" | "kolam"; langka: number };

export const IKAN: IkanDef[] = [
  { id: "sepat", nama: "Ikan Sepat", jual: 40, tempat: "sungai", langka: 1 },
  { id: "lele", nama: "Ikan Lele", jual: 70, tempat: "sungai", langka: 1 },
  { id: "nila", nama: "Ikan Nila", jual: 80, tempat: "sungai", langka: 1 },
  { id: "gabus", nama: "Ikan Gabus", jual: 110, tempat: "sungai", langka: 2 },
  { id: "belut", nama: "Belut", jual: 130, tempat: "sungai", langka: 2 },
  { id: "gurame", nama: "Ikan Gurame", jual: 220, tempat: "sungai", langka: 3 },
  { id: "mas", nama: "Ikan Mas", jual: 100, tempat: "kolam", langka: 1 },
  { id: "bawal", nama: "Ikan Bawal", jual: 160, tempat: "kolam", langka: 2 },
  { id: "kembung", nama: "Ikan Kembung", jual: 60, tempat: "laut", langka: 1 },
  { id: "udang", nama: "Udang", jual: 140, tempat: "laut", langka: 2 },
  { id: "baronang", nama: "Ikan Baronang", jual: 180, tempat: "laut", langka: 2 },
  { id: "tongkol", nama: "Ikan Tongkol", jual: 200, tempat: "laut", langka: 2 },
  { id: "kakap", nama: "Ikan Kakap", jual: 320, tempat: "laut", langka: 3 },
];

for (const i of IKAN) {
  lain({ id: i.id, nama: i.nama, kat: "hasil", jual: i.jual, deskripsi: i.nama + " hasil pancingan." });
}

export type Resep = { id: string; nama: string; bahan: [string, number][]; hasil: string };

export const RESEP: Resep[] = [
  { id: "nasigoreng", nama: "Nasi Goreng", bahan: [["padi", 1], ["telur", 1]], hasil: "nasigoreng" },
  { id: "sambal", nama: "Sambal Desa", bahan: [["cabai", 2], ["bawangmerah", 1]], hasil: "sambal" },
  { id: "supsayur", nama: "Sup Sayur", bahan: [["wortel", 1], ["kentang", 1], ["bayam", 1]], hasil: "supsayur" },
  { id: "jussemangka", nama: "Jus Semangka", bahan: [["semangka", 1]], hasil: "jussemangka" },
  { id: "kopisusu", nama: "Kopi Susu", bahan: [["susu", 1], ["kopi", 1]], hasil: "kopisusu" },
];

export type Festival = { id: string; nama: string; musim: Musim; hari: number; tempat: string; deskripsi: string };

export const FESTIVAL: Festival[] = [
  { id: "tahun", nama: "Perayaan Tahun Baru", musim: "hujan", hari: 1, tempat: "Balai Desa", deskripsi: "Doa bersama dan kue manis. Tahun pertama adalah hari kedatanganmu, pestanya mulai tahun kedua." },
  { id: "pancing", nama: "Lomba Memancing", musim: "hujan", hari: 10, tempat: "Sungai Cempaka", deskripsi: "Siapa paling banyak nilai ikan dalam tiga tarikan." },
  { id: "ayam", nama: "Lomba Ayam", musim: "hujan", hari: 20, tempat: "Alun Desa", deskripsi: "Ayam paling sehat dan sayang pada pemiliknya yang menang." },
  { id: "layang", nama: "Festival Layang-Layang", musim: "kemarau", hari: 8, tempat: "Pantai Kelapa", deskripsi: "Naikkan layang-layang dengan waktu yang pas." },
  { id: "merdeka", nama: "Festival Kemerdekaan", musim: "kemarau", hari: 17, tempat: "Balai Desa", deskripsi: "Kuis desa dan panjat semangat. Hadiahnya bendera kecil." },
  { id: "panen", nama: "Festival Panen", musim: "panen", hari: 7, tempat: "Balai Desa", deskripsi: "Bawa hasil ladang terbaikmu." },
  { id: "ternak", nama: "Festival Hewan Ternak", musim: "panen", hari: 21, tempat: "Kandang Ternak", deskripsi: "Tunjukkan hewan yang paling kamu rawat." },
  { id: "masak", nama: "Lomba Memasak", musim: "bunga", hari: 14, tempat: "Warung Kopi", deskripsi: "Sajikan masakan dari dapurmu." },
];

export const KUIS: { tanya: string; pilih: string[]; jawab: number }[] = [
  { tanya: "Desa tempat lahan kakekmu bernama?", pilih: ["Sukamaju", "Sukasari", "Mulyoharjo"], jawab: 0 },
  { tanya: "Siapa yang mewariskan ladang ini?", pilih: ["Pak Kades", "Kakek Harso", "Nenek Sumi"], jawab: 1 },
  { tanya: "Tanggal semangat kemerdekaan yang dirayakan desa?", pilih: ["17 Agustus", "1 Januari", "10 November"], jawab: 0 },
  { tanya: "Kalau tanaman tidak disiram, dia akan?", pilih: ["Langsung berbuah", "Layu lalu mati", "Jadi emas"], jawab: 1 },
  { tanya: "Hewan yang bulunya dipotong jadi wol?", pilih: ["Sapi", "Bebek", "Domba"], jawab: 2 },
];

export const SURAT = [
  "Nak, kalau kamu membaca ini, ladang di Desa Sukamaju sudah resmi milikmu. Aku Kakek Harso.",
  "Cangkul tanah, tabur benih, lalu siram. Taruh hasil di tong pengiriman, uangnya datang besok pagi.",
  "Sapa warga. Mereka baik, asal kamu tidak datang cuma saat butuh. Kalau lelah, tidur di kasur.",
  "Tidur di kasur adalah satu-satunya cara menyimpan hari. Mau simpan kapan saja, pakai Save State di menu.",
  "Gerak pakai WASD atau panah, bisa juga tuas. Interaksi Z. Alat X. Tas C. Menu Esc. Ganti alat Q.",
];

export const BANTUAN = [
  "PC: WASD atau panah gerak. Z interaksi. X pakai alat. C tas. Esc menu. Q ganti alat. 1-5 pilih alat.",
  "Layar sentuh: tuas kiri untuk gerak. Interaksi, Alat, Tas, dan Menu di kanan. Alat juga bisa dipilih di layar.",
  "Stamina habis bikin alat tidak bisa dipakai. Makan atau tidur. Gembor diisi di sumur, sungai, atau kolam.",
  "Musim berganti tiap 28 hari: Hujan, Kemarau, Panen, Bunga. Tanaman di luar musimnya akan mati.",
  "Hewan perlu makan tiap hari. Kalau lapar dua hari, mereka bisa sakit. Obat ada di toko Nenek Sumi.",
  "Lamaran butuh Cincin Janji dan hati yang sudah dekat. Setelah menikah, pasangan tinggal di rumahmu.",
];

export const KREDIT = [
  "Harvest Nusantara: Kehidupan Desa",
  "Sebuah permainan kehidupan desa yang dibuat orisinal.",
  "Semua nama, tempat, lagu, dan gambar adalah karya baru.",
  "Tidak berafiliasi dengan permainan pertanian lain.",
  "Desa Sukamaju, Sungai Cempaka, Pantai Kelapa, Bukit Wijaya.",
  "Terima kasih sudah menyiram tanaman dan menyapa tetangga.",
  "Selamat bertani.",
];

export const NAMA_ALAT: Record<string, string> = {
  cangkul: "Cangkul",
  gembor: "Gembor",
  sabit: "Sabit",
  palu: "Palu",
  pancing: "Pancing",
};

export const BAJU = ["#c4473a", "#3a6ec4", "#2f8f4a", "#8a5a32"];
export const NAMA_BAJU = ["Merah bata", "Biru sungai", "Hijau daun", "Coklat kayu"];

export function namaMusim(m: Musim) {
  return m === "hujan" ? "Musim Hujan" : m === "kemarau" ? "Musim Kemarau" : m === "panen" ? "Musim Panen" : "Musim Bunga";
}

export function namaMusimPendek(m: Musim) {
  return m === "hujan" ? "Hujan" : m === "kemarau" ? "Kemarau" : m === "panen" ? "Panen" : "Bunga";
}
