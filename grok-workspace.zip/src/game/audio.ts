import type { Cfg } from "./types";

let ac: AudioContext | null = null;
let musikGain: GainNode | null = null;
let efekGain: GainNode | null = null;
let trekId = "menu";
let langkah = 0;
let tunggu = 0;
let hidup = false;

const NADA = [261.63, 293.66, 329.63, 392, 440, 523.25, 587.33, 659.25];

const TREK: Record<string, number[]> = {
  menu: [0, 2, 4, 7, 4, 2, 0, -1, 4, 3, 2, 0, 2, 4, 2, 0],
  ladang: [0, 4, 2, 4, 5, 4, 2, 0, 3, 2, 0, 2, 4, 5, 4, 2],
  desa: [4, 2, 3, 4, 0, 2, 4, 3, 2, 0, 4, 2, 3, 4, 2, 0],
  pantai: [0, 2, 0, 4, 5, 4, 2, 4, 0, 3, 2, 0, -1, 2, 4, 5],
  tambang: [0, -1, 3, 1, 0, 3, 0, -1, 1, 0, 4, 3],
  malam: [0, 2, -1, 3, 2, 0, -1, 4, 3, 2, 0, -1],
  fest: [4, 4, 2, 4, 5, 4, 7, 5, 4, 2, 3, 4, 0, 2, 4, 5],
};

export function pastikanAudio() {
  if (hidup) return;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  ac = new Ctx();
  musikGain = ac.createGain();
  efekGain = ac.createGain();
  musikGain.connect(ac.destination);
  efekGain.connect(ac.destination);
  hidup = true;
}

export function terapkanAudio(c: Cfg) {
  if (!musikGain || !efekGain || !ac) return;
  musikGain.gain.value = c.musikNyala ? (c.musik / 100) * 0.08 : 0;
  efekGain.gain.value = c.efekNyala ? (c.efek / 100) * 0.18 : 0;
  if (ac.state === "suspended") void ac.resume();
}

export function setTrek(id: string) {
  if (trekId === id) return;
  trekId = id;
  langkah = 0;
}

export function langkahMusik(dt: number) {
  if (!ac || !hidup) return;
  const nada = TREK[trekId] ?? TREK.menu;
  tunggu -= dt;
  if (tunggu > 0) return;
  tunggu = trekId === "tambang" ? 0.42 : 0.34;
  const n = nada[langkah % nada.length];
  langkah++;
  if (n < 0) return;
  bunyi(NADA[n % NADA.length] * (n >= 6 ? 0.5 : 1), 0.3, "musik", n % 2 === 0 ? "triangle" : "sine");
}

function bunyi(frek: number, dur: number, bus: "musik" | "efek", tipe: OscillatorType) {
  if (!ac || !musikGain || !efekGain) return;
  const o = ac.createOscillator();
  const g = ac.createGain();
  o.type = tipe;
  o.frequency.value = frek;
  const now = ac.currentTime;
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.9, now + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  o.connect(g).connect(bus === "musik" ? musikGain : efekGain);
  o.start(now);
  o.stop(now + dur + 0.02);
}

export function sfx(nama: string) {
  if (!ac) return;
  if (nama === "ui") bunyi(520, 0.08, "efek", "square");
  else if (nama === "ok") {
    bunyi(523, 0.1, "efek", "square");
    bunyi(784, 0.14, "efek", "square");
  } else if (nama === "tidak") bunyi(180, 0.16, "efek", "sawtooth");
  else if (nama === "koin") {
    bunyi(880, 0.08, "efek", "square");
    bunyi(1174, 0.12, "efek", "square");
  } else if (nama === "cangkul") bunyi(140, 0.1, "efek", "square");
  else if (nama === "air") bunyi(700, 0.09, "efek", "sine");
  else if (nama === "panen") bunyi(640, 0.12, "efek", "triangle");
  else if (nama === "hewan") bunyi(420, 0.12, "efek", "square");
  else if (nama === "palu") bunyi(90, 0.09, "efek", "square");
  else bunyi(300, 0.06, "efek", "square");
}

export function trekUntuk(map: string, jam: number, fest: boolean, menu: boolean) {
  if (menu) return "menu";
  if (fest) return "fest";
  if (map === "tambang") return "tambang";
  if (map === "pantai") return "pantai";
  if (jam >= 19 || jam < 5) return "malam";
  if (map === "desa" || map === "pasar" || map === "warung" || map === "balai") return "desa";
  return "ladang";
}
