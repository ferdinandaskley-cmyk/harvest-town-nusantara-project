export const CW = 6;
export const CH = 8;

let atlas: HTMLCanvasElement | null = null;
const tint = new Map<string, HTMLCanvasElement>();

function bangun() {
  if (atlas) return atlas;
  const cols = 16;
  const rows = 6;
  const skala = 4;
  const src = document.createElement("canvas");
  src.width = cols * CW * skala;
  src.height = rows * CH * skala;
  const g = src.getContext("2d")!;
  g.clearRect(0, 0, src.width, src.height);
  g.fillStyle = "#fff";
  g.font = "bold " + CW * skala + "px ui-monospace, monospace";
  g.textAlign = "center";
  g.textBaseline = "middle";
  for (let i = 0; i < 95; i++) {
    const col = i % cols;
    const row = Math.floor(i / cols);
    g.fillText(String.fromCharCode(32 + i), (col + 0.5) * CW * skala, (row + 0.52) * CH * skala);
  }
  const data = g.getImageData(0, 0, src.width, src.height).data;
  const out = document.createElement("canvas");
  out.width = cols * CW;
  out.height = rows * CH;
  const og = out.getContext("2d")!;
  const img = og.createImageData(out.width, out.height);
  for (let py = 0; py < out.height; py++) {
    for (let px = 0; px < out.width; px++) {
      let c = 0;
      for (let y = 0; y < skala; y++) {
        for (let x = 0; x < skala; x++) {
          const sx = px * skala + x;
          const sy = py * skala + y;
          const p = (sy * src.width + sx) * 4;
          if (data[p + 3] > 80 && data[p] > 40) c++;
        }
      }
      const i = (py * out.width + px) * 4;
      const nyala = c >= 4;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
      img.data[i + 3] = nyala ? 255 : 0;
    }
  }
  og.putImageData(img, 0, 0);
  atlas = out;
  return out;
}

function warnaAtlas(warna: string) {
  const ada = tint.get(warna);
  if (ada) return ada;
  const dasar = bangun();
  const c = document.createElement("canvas");
  c.width = dasar.width;
  c.height = dasar.height;
  const g = c.getContext("2d")!;
  g.drawImage(dasar, 0, 0);
  g.globalCompositeOperation = "source-in";
  g.fillStyle = warna;
  g.fillRect(0, 0, c.width, c.height);
  tint.set(warna, c);
  return c;
}

export function lebar(s: string, skala = 1) {
  return s.length * CW * skala;
}

export function bungkus(s: string, max: number) {
  const kata = s.split(" ");
  const baris: string[] = [];
  let cur = "";
  for (const w of kata) {
    const n = cur ? cur + " " + w : w;
    if (n.length > max && cur) {
      baris.push(cur);
      cur = w;
    } else cur = n;
  }
  if (cur) baris.push(cur);
  return baris.length ? baris : [""];
}

export function teks(ctx: CanvasRenderingContext2D, s: string, x: number, y: number, warna: string, skala = 1) {
  const img = warnaAtlas(warna);
  const cols = 16;
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code < 32 || code > 126) continue;
    const idx = code - 32;
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    ctx.drawImage(img, col * CW, row * CH, CW, CH, Math.round(x + i * CW * skala), Math.round(y), CW * skala, CH * skala);
  }
}

export function teksBayang(ctx: CanvasRenderingContext2D, s: string, x: number, y: number, warna: string, skala = 1) {
  teks(ctx, s, x + skala, y + skala, "#1a120c", skala);
  teks(ctx, s, x, y, warna, skala);
}
