import { FESTIVAL, HEWAN, IKAN, ITEM, RESEP, TANAMAN_MAP, namaMusim } from "./data";
import { NPCS, NPC_MAP, type NpcDef } from "./npc";
import { PETAS, ambil, buatTambang, padat } from "./maps";
import {
  ALAT,
  CHEAT_DAFTAR,
  MUSIM,
  STAMINA_MAX,
  type AlatId,
  type Arah,
  type Cfg,
  type CheatId,
  type Hewan,
  type Musim,
  type Plot,
  type SaveData,
  type Slot,
} from "./types";

export function rp(n: number) {
  return "Rp " + Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export function jamLabel(jam: number, menit: number) {
  const h = ((jam % 24) + 24) % 24;
  return String(h).padStart(2, "0") + ":" + String(menit | 0).padStart(2, "0");
}

export function absHari(s: Pick<SaveData, "tahun" | "musim" | "hari">) {
  return (s.tahun - 1) * 112 + MUSIM.indexOf(s.musim) * 28 + s.hari;
}

export function curang(cfg: Cfg, id: CheatId) {
  return !!cfg.cheats[id];
}

export function jumlahCurang(cfg: Cfg) {
  return CHEAT_DAFTAR.filter((c) => cfg.cheats[c.id]).length;
}

export function hargaJual(sl: Slot) {
  const d = ITEM[sl.id];
  if (!d) return 0;
  const dasar = d.jual || 0;
  return sl.subur ? Math.floor(dasar * 1.5) : dasar;
}

export function hitung(inv: (Slot | null)[], id: string) {
  let n = 0;
  for (const s of inv) if (s && s.id === id) n += s.n;
  return n;
}

export function adaRuang(inv: (Slot | null)[], id: string, n: number, subur = false) {
  let sisa = n;
  for (const s of inv) {
    if (s && s.id === id && !!s.subur === subur) sisa -= Math.max(0, 99 - s.n);
  }
  for (const s of inv) if (!s) sisa -= 99;
  return sisa <= 0;
}

export function taruh(inv: (Slot | null)[], id: string, n: number, subur = false) {
  for (const s of inv) {
    if (n <= 0) break;
    if (s && s.id === id && !!s.subur === subur && s.n < 99) {
      const add = Math.min(99 - s.n, n);
      s.n += add;
      n -= add;
    }
  }
  for (let i = 0; i < inv.length && n > 0; i++) {
    if (!inv[i]) {
      const add = Math.min(99, n);
      inv[i] = subur ? { id, n: add, subur: true } : { id, n: add };
      n -= add;
    }
  }
  return n;
}

export function ambil(inv: (Slot | null)[], id: string, n: number) {
  if (hitung(inv, id) < n) return false;
  for (const s of inv) {
    if (n <= 0) break;
    if (s && s.id === id) {
      const k = Math.min(s.n, n);
      s.n -= k;
      n -= k;
    }
  }
  for (let i = 0; i < inv.length; i++) if (inv[i] && inv[i]!.n <= 0) inv[i] = null;
  return true;
}

export function ambilSlot(inv: (Slot | null)[], idx: number, n = 1) {
  const s = inv[idx];
  if (!s || s.n < n) return null;
  const out = { id: s.id, n, subur: s.subur };
  s.n -= n;
  if (s.n <= 0) inv[idx] = null;
  return out;
}

export function levelAlat(s: SaveData, cfg: Cfg, alat: AlatId) {
  if (curang(cfg, "alat")) return 4;
  return s.levelAlat[alat] || 1;
}

export function kapasitasAir(s: SaveData, cfg: Cfg) {
  if (curang(cfg, "air")) return 999;
  return [0, 20, 35, 50, 80][levelAlat(s, cfg, "gembor")] ?? 20;
}

export function areaBuka(s: SaveData, cfg: Cfg, kunci?: "pantai" | "gunung") {
  if (!kunci) return true;
  if (curang(cfg, "area")) return true;
  const h = absHari(s);
  if (kunci === "pantai") return h >= 3;
  if (kunci === "gunung") return h >= 6;
  return true;
}

export function pesanKunci(kunci?: "pantai" | "gunung") {
  if (kunci === "pantai") return "Jalan ke pantai masih longsor. Nanti hari ke-3 sudah aman.";
  if (kunci === "gunung") return "Bukit Wijaya belum dibuka. Tunggu hari ke-6, atau minta tolong Rama.";
  return "Jalan ini belum bisa dilewati.";
}

export function hatiNpc(s: SaveData, cfg: Cfg, id: string) {
  if (curang(cfg, "npc")) return 100;
  return s.npc[id]?.hati ?? 0;
}

export function kasihHewan(h: Hewan, cfg: Cfg) {
  if (curang(cfg, "hewanHati")) return 100;
  return h.kasih;
}

export function kapasitasKandang(s: SaveData, cfg: Cfg, jenis: "ayam" | "besar") {
  const lv = jenis === "ayam" ? s.kandangAyam : s.kandangBesar;
  const dasar = jenis === "ayam" ? [0, 4, 6, 8][lv] : [0, 3, 5, 7][lv];
  return (dasar ?? 4) + (curang(cfg, "hewan") ? 4 : 0);
}

export function jumlahKandang(s: SaveData, jenis: "ayam" | "besar") {
  return s.hewan.filter((h) => HEWAN[h.jenis]?.kandang === jenis).length;
}

export function tahap(p: Plot) {
  if (!p.tanaman) return -1;
  const def = TANAMAN_MAP[p.tanaman];
  if (!def) return 0;
  if (p.tumbuh >= def.hari) return 3;
  const t = p.tumbuh / def.hari;
  if (t >= 0.66) return 2;
  if (t >= 0.33) return 1;
  return 0;
}

export function petakDepan(x: number, y: number, arah: Arah, jarak = 14) {
  const v = arah === "kiri" ? [-1, 0] : arah === "kanan" ? [1, 0] : arah === "atas" ? [0, -1] : [0, 1];
  return { x: Math.floor((x + v[0] * jarak) / 16), y: Math.floor((y + v[1] * jarak) / 16) };
}

export function petakAyun(lv: number, tx: number, ty: number, arah: Arah) {
  const out: { x: number; y: number }[] = [{ x: tx, y: ty }];
  const dx = arah === "kiri" ? -1 : arah === "kanan" ? 1 : 0;
  const dy = arah === "atas" ? -1 : arah === "bawah" ? 1 : 0;
  const px = dy !== 0 ? 1 : 0;
  const py = dx !== 0 ? 1 : 0;
  if (lv >= 2) {
    out.push({ x: tx + px, y: ty + py }, { x: tx - px, y: ty - py });
  }
  if (lv >= 3) {
    out.push({ x: tx + dx, y: ty + dy }, { x: tx + dx + px, y: ty + dy + py }, { x: tx + dx - px, y: ty + dy - py });
  }
  if (lv >= 4) {
    out.push({ x: tx + px * 2, y: ty + py * 2 }, { x: tx - px * 2, y: ty - py * 2 });
    out.push({ x: tx + dx * 2, y: ty + dy * 2 });
  }
  const ada = new Set<string>();
  return out.filter((p) => {
    const k = p.x + "," + p.y;
    if (ada.has(k)) return false;
    ada.add(k);
    return true;
  });
}

export function dalamJam(h: number, a: number, b: number) {
  if (a === b) return true;
  if (a < b) return h >= a && h < b;
  return h >= a || h < b;
}

export function tujuanNpc(def: NpcDef, s: SaveData) {
  if (s.pasangan === def.id) {
    const h = s.jam;
    let map = "rumah";
    let tempat = "tengah";
    if (h >= 6 && h < 9) tempat = "dapur";
    else if (h >= 9 && h < 13) {
      map = "ladang";
      tempat = "tengah";
    } else if (h >= 13 && h < 16) {
      map = "desa";
      tempat = "alun";
    } else if (h >= 21 || h < 6) tempat = "sisi";
    const j = PETAS[map].jangkar[tempat];
    return { map, x: j.x * 16 + 8, y: j.y * 16 + 8 };
  }
  let pilih = def.jadwal[def.jadwal.length - 1];
  for (const j of def.jadwal) {
    if (dalamJam(s.jam, j.a, j.b)) {
      pilih = j;
      break;
    }
  }
  const jang = PETAS[pilih.map]?.jangkar[pilih.tempat] ?? { x: 2, y: 2 };
  const geser = (def.id.charCodeAt(0) % 5) - 2;
  return { map: pilih.map, x: jang.x * 16 + 8 + geser, y: jang.y * 16 + 8 };
}

export function festivalPada(s: SaveData) {
  return (
    FESTIVAL.find((f) => {
      if (f.musim !== s.musim || f.hari !== s.hari) return false;
      if (f.id === "tahun" && s.tahun < 2) return false;
      return true;
    }) ?? null
  );
}

export function kunciFest(id: string, s: SaveData) {
  return id + "_t" + s.tahun;
}

export function reaksiHadiah(def: NpcDef, id: string) {
  if (def.cinta.includes(id)) return { teks: "Wah, ini kesukaanku!", poin: 20 };
  if (def.suka.includes(id)) return { teks: "Terima kasih, aku suka.", poin: 10 };
  if (def.tidak.includes(id)) return { teks: "Maaf, aku kurang suka ini.", poin: -10 };
  return { teks: "Terima kasih sudah ingat aku.", poin: 4 };
}

export function dialogNpc(def: NpcDef, s: SaveData, cfg: Cfg) {
  const hati = hatiNpc(s, cfg, def.id);
  if (s.pasangan === def.id && def.nikah.length) return def.nikah[absHari(s) % def.nikah.length];
  const pool = hati >= 70 ? def.dekat : hati >= 30 ? def.akrab : def.baru;
  return pool[absHari(s) % pool.length];
}

export function peristiwaNpc(def: NpcDef, s: SaveData) {
  const mem = s.npc[def.id];
  if (!mem || !def.romansa) return null;
  const batas = [
    { id: "40", hati: 40, baris: [def.nama + " tampak senang kamu sering mampir.", def.kerja + " itu bukan cuma kerja, katanya, kalau ada teman."] },
    { id: "75", hati: 75, baris: ["Aku nyaman kalau kamu di dekat sini.", "Kalau suatu hari ada cincin dan hatimu yakin, katakan saja."] },
  ];
  for (const e of batas) {
    if (mem.hati >= e.hati && !mem.ev.includes(e.id)) return e;
  }
  return null;
}

export function tujuanCerita(s: SaveData) {
  const hatiMaks = Math.max(0, ...Object.values(s.npc).map((n) => n.hati));
  return [
    { teks: "Panen 5 tanaman", selesai: s.stat.panen >= 5 },
    { teks: "Kumpulkan Rp 5.000 dari penjualan", selesai: s.stat.penghasilan >= 5000 },
    { teks: "Mengobrol dengan 6 warga", selesai: s.stat.kenalan.length >= 6 },
    { teks: "Pelihara satu hewan", selesai: s.hewan.length >= 0 && s.hewan.some(() => true) },
    { teks: "Ikuti satu festival", selesai: s.stat.festival >= 1 },
    { teks: "Capai 5 hati dengan seseorang", selesai: hatiMaks >= 50 },
    { teks: "Menikah", selesai: !!s.pasangan },
    { teks: "Menyambut anak", selesai: !!s.anak },
  ];
}

export function ceritaSelesai(s: SaveData) {
  return tujuanCerita(s).every((t) => t.selesai);
}

export function biayaUpgrade(lv: number) {
  const tabel = [
    null,
    { uang: 800, besi: 3, emas: 0, permata: 0 },
    { uang: 2500, besi: 5, emas: 2, permata: 0 },
    { uang: 6000, besi: 0, emas: 5, permata: 2 },
  ];
  return tabel[lv] ?? null;
}

export function biayaKandang(jenis: "ayam" | "besar", lv: number) {
  if (jenis === "ayam") return lv === 1 ? 2000 : lv === 2 ? 5000 : 0;
  return lv === 1 ? 3000 : lv === 2 ? 8000 : 0;
}

export function ikanTempat(map: string, ch: string) {
  if (ch === "W" || map === "pantai") return "laut" as const;
  if (map === "sawah") return "kolam" as const;
  return "sungai" as const;
}

export function pilihIkan(tempat: "sungai" | "laut" | "kolam", semua: boolean) {
  let pool = IKAN.filter((i) => i.tempat === tempat);
  if (semua) pool = IKAN.slice();
  if (!pool.length) pool = IKAN.slice();
  const berat = pool.map((i) => (semua ? 1 : 4 - i.langka));
  let total = berat.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < pool.length; i++) {
    r -= berat[i];
    if (r <= 0) return pool[i];
  }
  return pool[0];
}

export function bisaMasak(inv: (Slot | null)[], id: string) {
  const r = RESEP.find((x) => x.id === id);
  if (!r) return false;
  return r.bahan.every(([b, n]) => hitung(inv, b) >= n);
}

export function plotDi(s: SaveData, x: number, y: number) {
  return s.lahan.find((p) => p.x === x && p.y === y) ?? null;
}

export function ubinDasar(map: string, x: number, y: number, tambang: string[][] | null) {
  if (map === "tambang" && tambang) return ambil(tambang, x, y);
  const p = PETAS[map];
  if (!p) return "#";
  return ambil(p.tiles, x, y);
}

export function ubinTampil(s: SaveData, map: string, x: number, y: number, tambang: string[][] | null) {
  const ch = ubinDasar(map, x, y, tambang);
  if (ch === "G" && s.rumput.includes(map + ":" + x + "," + y)) return "g";
  return ch;
}

export function terhalang(s: SaveData, map: string, px: number, py: number, tambang: string[][] | null) {
  const tx = Math.floor(px / 16);
  const ty = Math.floor(py / 16);
  return padat(ubinTampil(s, map, tx, ty, tambang));
}

export function majuHari(s: SaveData, cfg: Cfg, pingsan: boolean) {
  const catatan: string[] = [];
  let uang = 0;
  for (let i = 0; i < s.bin.length; i++) {
    const sl = s.bin[i];
    if (!sl) continue;
    uang += hargaJual(sl) * sl.n;
    s.bin[i] = null;
  }
  if (uang > 0) {
    s.uang += uang;
    s.stat.penghasilan += uang;
    catatan.push("Tong pengiriman laku " + rp(uang) + ".");
  }
  if (s.pasangan) {
    let c = 0;
    for (const p of s.lahan) {
      if (c >= 6) break;
      if (p.tanaman && !p.siram) {
        p.siram = true;
        c++;
      }
    }
    if (c) catatan.push("Pasanganmu menyiram beberapa tanaman.");
  }
  if (s.cuaca === "hujan") {
    let c = 0;
    for (const p of s.lahan) {
      if ((p.tanaman || p.cangkul) && !p.siram) c++;
      if (p.tanaman || p.cangkul) p.siram = true;
    }
    if (c) catatan.push("Hujan semalam menyiram ladang.");
  }
  const mati: string[] = [];
  for (const p of s.lahan) {
    if (!p.tanaman) {
      p.siram = false;
      continue;
    }
    const def = TANAMAN_MAP[p.tanaman];
    if (!def) continue;
    if (p.siram) {
      p.layu = 0;
      p.tumbuh += p.pupuk ? 2 : 1;
      if (curang(cfg, "tumbuh")) p.tumbuh = def.hari;
    } else {
      p.layu += 1;
      if (p.layu >= 2) {
        mati.push(def.nama);
        p.tanaman = null;
        p.tumbuh = 0;
        p.layu = 0;
        p.pupuk = false;
      }
    }
    p.siram = false;
  }
  if (mati.length) catatan.push(mati.slice(0, 2).join(" dan ") + " mati karena kekeringan.");

  for (const h of s.hewan) {
    h.umur += 1;
    if (h.hamil > 0) {
      h.hamil -= 1;
      if (h.hamil <= 0) {
        const jenis = h.jenis;
        const kandang = HEWAN[jenis].kandang;
        if (jumlahKandang(s, kandang) < kapasitasKandang(s, cfg, kandang)) {
          s.nextUid += 1;
          s.hewan.push({
            uid: s.nextUid,
            jenis,
            nama: HEWAN[jenis].nama + " kecil",
            gender: Math.random() < 0.5 ? "j" : "b",
            kasih: 20,
            kenyang: false,
            lapar: 0,
            sakit: false,
            siap: false,
            wol: 0,
            umur: 0,
            hamil: 0,
          });
          catatan.push(h.nama + " beranak.");
        } else {
          h.hamil = 1;
          catatan.push("Kandang penuh, kelahiran ditunda.");
        }
      }
    }
    const dewasa = h.umur >= 7;
    if (!h.kenyang) {
      h.lapar += 1;
      h.kasih = Math.max(0, h.kasih - 6);
      if (h.lapar >= 2 && !curang(cfg, "sakit")) h.sakit = true;
    } else {
      h.lapar = 0;
      h.kasih = Math.min(100, h.kasih + 3);
    }
    if (curang(cfg, "sakit")) h.sakit = false;
    if (h.sakit) h.siap = false;
    else if (dewasa && h.kenyang) {
      const def = HEWAN[h.jenis];
      if (def.hari <= 1) h.siap = true;
      else {
        h.wol += 1;
        if (h.wol >= def.hari) {
          h.siap = true;
          h.wol = 0;
        }
      }
    }
    h.kenyang = false;
  }

  const musimLama = s.musim;
  s.hari += 1;
  if (s.hari > 28) {
    s.hari = 1;
    const i = MUSIM.indexOf(s.musim);
    s.musim = MUSIM[(i + 1) % 4];
    if (i === 3) s.tahun += 1;
    s.rumput = [];
    if (!curang(cfg, "tanaman")) {
      let ada = false;
      for (const p of s.lahan) {
        if (!p.tanaman) continue;
        const d = TANAMAN_MAP[p.tanaman];
        if (d && !d.musim.includes(s.musim)) {
          p.tanaman = null;
          p.tumbuh = 0;
          p.pupuk = false;
          p.layu = 0;
          ada = true;
        }
      }
      if (ada) catatan.push("Sebagian tanaman tidak tahan " + namaMusim(s.musim) + ".");
    }
    if (musimLama !== s.musim) catatan.push("Musim berganti menjadi " + namaMusim(s.musim) + ".");
  }

  s.cuaca = acakCuaca(s);
  for (const n of Object.values(s.npc)) {
    n.bicara = false;
    n.hadiah = false;
    n.kencan = false;
  }
  s.petik = [];
  if (s.anak) s.anak.umur += 1;

  if (s.tungguNikah) {
    s.pasangan = s.tungguNikah;
    s.hariNikah = absHari(s);
    s.tungguNikah = null;
    s.adegan = "nikah";
  } else if (s.pasangan && !s.anak && s.adegan !== "nikah") {
    if (absHari(s) - s.hariNikah >= 14) s.adegan = "anak";
  }

  if (pingsan) {
    const rugi = curang(cfg, "uang") ? 0 : Math.min(s.uang, Math.max(100, Math.floor(s.uang * 0.1)));
    s.uang -= rugi;
    s.stamina = 40;
    catatan.push(rugi > 0 ? "Kamu pingsan. Kehilangan " + rp(rugi) + "." : "Kamu pingsan karena kelelahan.");
  } else s.stamina = STAMINA_MAX;

  s.jam = 6;
  s.menit = 0;
  s.air = kapasitasAir(s, cfg) === 999 ? s.air : kapasitasAir(s, cfg);
  const rumah = PETAS.rumah.jangkar.tengah;
  s.map = "rumah";
  s.x = rumah.x * 16 + 8;
  s.y = rumah.y * 16 + 8;
  s.arah = "bawah";
  s.tambangData = null;

  if (!s.tamat && s.adegan !== "anak" && s.adegan !== "nikah" && ceritaSelesai(s)) s.adegan = "tamat";

  const fest = festivalPada(s);
  if (fest && !s.festSelesai.includes(kunciFest(fest.id, s))) {
    catatan.push("Hari ini " + fest.nama + ". Temui Pak Kades di balai.");
  }
  if (s.cuaca === "hujan") catatan.push("Langit mendung. Sepertinya akan hujan.");
  return catatan;
}

function acakCuaca(s: SaveData): SaveData["cuaca"] {
  const r = Math.random();
  if (s.musim === "hujan") return r < 0.55 ? "hujan" : r < 0.8 ? "berawan" : "cerah";
  if (s.musim === "kemarau") return r < 0.08 ? "hujan" : r < 0.35 ? "berawan" : "cerah";
  return r < 0.22 ? "hujan" : r < 0.5 ? "berawan" : "cerah";
}

export function tambahMenit(s: SaveData, cfg: Cfg, n: number) {
  if (curang(cfg, "waktu") || n <= 0) return false;
  s.menit += n;
  while (s.menit >= 60) {
    s.menit -= 60;
    s.jam += 1;
  }
  return s.jam >= 26;
}

export function pakaiStamina(s: SaveData, cfg: Cfg, n: number) {
  if (curang(cfg, "stamina")) return true;
  if (s.stamina < n) return false;
  s.stamina -= n;
  return true;
}

export function bayar(s: SaveData, cfg: Cfg, n: number) {
  if (curang(cfg, "uang")) return true;
  if (s.uang < n) return false;
  s.uang -= n;
  return true;
}

export function hewanTerbuka(cfg: Cfg, id: string) {
  const d = HEWAN[id];
  if (!d) return false;
  if (!d.kunci) return true;
  return curang(cfg, "hewan");
}

export function benihToko(s: SaveData, cfg: Cfg) {
  return Object.values(ITEM).filter((it) => {
    if (it.kat !== "benih" || !it.tanam) return false;
    if (curang(cfg, "benih")) return true;
    const t = TANAMAN_MAP[it.tanam];
    return t.musim.includes(s.musim);
  });
}

export function barangUmum() {
  const ids = ["pupuk", "pakan", "obat", "cincin", "bunga", "tikar", "vas", "lampu", "lukisan"];
  return ids.map((id) => ITEM[id]).filter((x) => !!x);
}

export const TOKO_WARUNG = ["nasi", "kopi", "gorengan", "sate", "esjeruk"];

export function namaItem(id: string) {
  return ITEM[id]?.nama ?? "Barang";
}

export function alatDariAngka(n: number): AlatId {
  return ALAT[Math.max(0, Math.min(4, n))] ?? "cangkul";
}

export function bolehTurun(s: SaveData, cfg: Cfg, lantai: number) {
  if (lantai < 5) return true;
  if (curang(cfg, "area") || curang(cfg, "alat")) return true;
  return levelAlat(s, cfg, "palu") >= 2;
}

export function hasilTambang(lantai: number) {
  const r = Math.random();
  if (lantai >= 9) return r < 0.45 ? "permata" : "emas";
  if (lantai >= 6) return r < 0.25 ? "permata" : r < 0.6 ? "emas" : "besi";
  if (lantai >= 3) return r < 0.2 ? "emas" : r < 0.65 ? "besi" : "batu";
  return r < 0.25 ? "besi" : "batu";
}

export function susunTambang(lantai: number, biji: number) {
  return buatTambang(lantai, biji);
}

export function cukupBahan(s: SaveData, besi: number, emas: number, permata: number) {
  return hitung(s.tas, "besi") >= besi && hitung(s.tas, "emas") >= emas && hitung(s.tas, "permata") >= permata;
}

export function NPC_LIST = NPCS;
export { NPC_MAP, RESEP, ITEM };
