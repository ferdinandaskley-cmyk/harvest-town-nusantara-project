import { NPCS } from "./npc";
import { PETAS } from "./maps";
import {
  ALAT,
  UK_BIN,
  UK_LEMARI,
  UK_TAS,
  VERSI,
  cheatsKosong,
  type AlatId,
  type Cfg,
  type CheatId,
  type Hewan,
  type Musim,
  type Plot,
  type SaveData,
  type Slot,
} from "./types";
import { CHEAT_DAFTAR } from "./types";

const K_SAVE = "hn_desa_simpan_v1";
const K_BAK = "hn_desa_simpan_bak_v1";
const K_SLOT = "hn_desa_slot_v1";
const K_CFG = "hn_desa_atur_v1";

export function cfgAwal(): Cfg {
  return {
    musik: 70,
    efek: 80,
    musikNyala: true,
    efekNyala: true,
    tombol: "sedang",
    layarPenuh: false,
    sentuh: true,
    cheats: cheatsKosong(),
  };
}

function kosong(n: number): (Slot | null)[] {
  return Array.from({ length: n }, () => null);
}

export function defaultSave(nama: string, baju: number): SaveData {
  const rumah = PETAS.rumah.jangkar.tengah;
  const npc: SaveData["npc"] = {};
  for (const n of NPCS) npc[n.id] = { hati: 0, bicara: false, hadiah: false, kencan: false, ev: [] };
  const levelAlat = {} as Record<AlatId, number>;
  for (const a of ALAT) levelAlat[a] = 1;
  const tas = kosong(UK_TAS);
  tas[0] = { id: "benih_padi", n: 8 };
  tas[1] = { id: "benih_kangkung", n: 4 };
  tas[2] = { id: "pakan", n: 3 };
  return {
    version: VERSI,
    nama: nama.slice(0, 10) || "Tani",
    baju,
    uang: 1500,
    stamina: 100,
    jam: 6,
    menit: 0,
    hari: 1,
    musim: "hujan",
    tahun: 1,
    cuaca: "cerah",
    map: "rumah",
    x: rumah.x * 16 + 8,
    y: rumah.y * 16 + 8,
    arah: "bawah",
    alat: "cangkul",
    levelAlat,
    air: 20,
    punyaPancing: false,
    tas,
    lemari: kosong(UK_LEMARI),
    bin: kosong(UK_BIN),
    lahan: [],
    rumput: [],
    petik: [],
    hewan: [],
    kandangAyam: 1,
    kandangBesar: 1,
    npc,
    pasangan: null,
    tungguNikah: null,
    hariNikah: 0,
    anak: null,
    ikan: [],
    dekor: [],
    flag: {},
    festSelesai: [],
    stat: { panen: 0, penghasilan: 0, kenalan: [], festival: 0 },
    nextUid: 1,
    pesanPagi: [],
    adegan: "surat",
    tamat: false,
    simpanPada: "",
    cheats: cheatsKosong(),
    tambangData: null,
  };
}

function baca(k: string): unknown {
  try {
    const t = localStorage.getItem(k);
    if (!t) return null;
    return JSON.parse(t);
  } catch {
    return null;
  }
}

function tulis(k: string, v: unknown) {
  try {
    localStorage.setItem(k, JSON.stringify(v));
    return true;
  } catch {
    return false;
  }
}

function slotAman(raw: unknown, n: number): (Slot | null)[] {
  const out = kosong(n);
  if (!Array.isArray(raw)) return out;
  for (let i = 0; i < n && i < raw.length; i++) {
    const s = raw[i];
    if (!s || typeof s !== "object") continue;
    const id = (s as Slot).id;
    const jumlah = (s as Slot).n;
    if (typeof id !== "string" || typeof jumlah !== "number" || jumlah <= 0) continue;
    out[i] = { id, n: Math.min(99, Math.floor(jumlah)), subur: !!(s as Slot).subur || undefined };
  }
  return out;
}

const MUSIM_OK = new Set<Musim>(["hujan", "kemarau", "panen", "bunga"]);

export function bersihkan(raw: unknown): SaveData | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Partial<SaveData>;
  if (typeof r.nama !== "string") return null;
  const s = defaultSave(r.nama, typeof r.baju === "number" ? r.baju % 4 : 0);
  const angka: (keyof SaveData)[] = ["uang", "stamina", "jam", "menit", "hari", "tahun", "air", "kandangAyam", "kandangBesar", "nextUid", "hariNikah"];
  for (const k of angka) {
    const v = r[k];
    if (typeof v === "number" && Number.isFinite(v)) (s as unknown as Record<string, number>)[k] = v;
  }
  if (r.musim && MUSIM_OK.has(r.musim)) s.musim = r.musim;
  if (r.cuaca === "cerah" || r.cuaca === "berawan" || r.cuaca === "hujan") s.cuaca = r.cuaca;
  if (typeof r.map === "string" && PETAS[r.map]) s.map = r.map;
  if (typeof r.x === "number") s.x = r.x;
  if (typeof r.y === "number") s.y = r.y;
  if (r.arah === "atas" || r.arah === "bawah" || r.arah === "kiri" || r.arah === "kanan") s.arah = r.arah;
  if (r.alat === "cangkul" || r.alat === "gembor" || r.alat === "sabit" || r.alat === "palu" || r.alat === "pancing") s.alat = r.alat;
  if (r.levelAlat && typeof r.levelAlat === "object") {
    for (const a of ALAT) {
      const lv = r.levelAlat[a];
      if (typeof lv === "number") s.levelAlat[a] = Math.max(1, Math.min(4, lv | 0));
    }
  }
  s.punyaPancing = !!r.punyaPancing;
  s.tas = slotAman(r.tas, UK_TAS);
  s.lemari = slotAman(r.lemari, UK_LEMARI);
  s.bin = slotAman(r.bin, UK_BIN);
  if (Array.isArray(r.lahan)) {
    s.lahan = r.lahan.filter((p): p is Plot => !!p && typeof p.x === "number" && typeof p.y === "number");
  }
  if (Array.isArray(r.rumput)) s.rumput = r.rumput.filter((x) => typeof x === "string");
  if (Array.isArray(r.petik)) s.petik = r.petik.filter((x) => typeof x === "string");
  if (Array.isArray(r.hewan)) {
    s.hewan = (r.hewan as Hewan[]).filter((h) => h && typeof h.jenis === "string" && typeof h.uid === "number");
  }
  if (r.npc && typeof r.npc === "object") {
    for (const n of NPCS) {
      const m = r.npc[n.id];
      if (!m) continue;
      s.npc[n.id] = {
        hati: Math.max(0, Math.min(100, m.hati | 0)),
        bicara: !!m.bicara,
        hadiah: !!m.hadiah,
        kencan: !!m.kencan,
        ev: Array.isArray(m.ev) ? m.ev.filter((e) => typeof e === "string") : [],
      };
    }
  }
  s.pasangan = typeof r.pasangan === "string" ? r.pasangan : null;
  s.tungguNikah = typeof r.tungguNikah === "string" ? r.tungguNikah : null;
  if (r.anak && typeof r.anak === "object" && typeof r.anak.nama === "string") {
    s.anak = { nama: r.anak.nama.slice(0, 10), umur: r.anak.umur | 0 };
  }
  if (Array.isArray(r.ikan)) s.ikan = r.ikan.filter((x) => typeof x === "string");
  if (Array.isArray(r.dekor)) s.dekor = r.dekor.filter((x) => typeof x === "string");
  if (r.flag && typeof r.flag === "object") s.flag = { ...r.flag };
  if (Array.isArray(r.festSelesai)) s.festSelesai = r.festSelesai.filter((x) => typeof x === "string");
  if (r.stat && typeof r.stat === "object") {
    s.stat.panen = r.stat.panen | 0;
    s.stat.penghasilan = r.stat.penghasilan | 0;
    s.stat.festival = r.stat.festival | 0;
    s.stat.kenalan = Array.isArray(r.stat.kenalan) ? r.stat.kenalan.filter((x) => typeof x === "string") : [];
  }
  if (Array.isArray(r.pesanPagi)) s.pesanPagi = r.pesanPagi.filter((x) => typeof x === "string");
  if (r.adegan === "surat" || r.adegan === "nikah" || r.adegan === "anak" || r.adegan === "tamat" || r.adegan === "") s.adegan = r.adegan;
  s.tamat = !!r.tamat;
  s.simpanPada = typeof r.simpanPada === "string" ? r.simpanPada : "";
  if (r.cheats && typeof r.cheats === "object") {
    for (const c of CHEAT_DAFTAR) s.cheats[c.id] = !!(r.cheats as Record<string, boolean>)[c.id];
  }
  if (r.tambangData && typeof r.tambangData === "object" && Array.isArray(r.tambangData.baris)) {
    s.tambangData = {
      lantai: r.tambangData.lantai | 0,
      biji: r.tambangData.biji | 0,
      baris: r.tambangData.baris.filter((x) => typeof x === "string"),
    };
  }
  s.version = VERSI;
  s.hari = Math.max(1, Math.min(28, s.hari | 0));
  s.tahun = Math.max(1, s.tahun | 0);
  s.stamina = Math.max(0, Math.min(100, s.stamina | 0));
  return s;
}

export function muatCfg(): Cfg {
  const raw = baca(K_CFG) as Partial<Cfg> | null;
  const c = cfgAwal();
  if (!raw || typeof raw !== "object") return c;
  if (typeof raw.musik === "number") c.musik = Math.max(0, Math.min(100, raw.musik));
  if (typeof raw.efek === "number") c.efek = Math.max(0, Math.min(100, raw.efek));
  if (typeof raw.musikNyala === "boolean") c.musikNyala = raw.musikNyala;
  if (typeof raw.efekNyala === "boolean") c.efekNyala = raw.efekNyala;
  if (raw.tombol === "kecil" || raw.tombol === "sedang" || raw.tombol === "besar") c.tombol = raw.tombol;
  c.layarPenuh = !!raw.layarPenuh;
  if (typeof raw.sentuh === "boolean") c.sentuh = raw.sentuh;
  if (raw.cheats) for (const x of CHEAT_DAFTAR) c.cheats[x.id] = !!raw.cheats[x.id as CheatId];
  return c;
}

export function simpanCfg(c: Cfg) {
  tulis(K_CFG, c);
}

export function adaSimpanan() {
  return !!baca(K_SAVE);
}

export function muatNormal() {
  return bersihkan(baca(K_SAVE));
}

export function simpanNormal(s: SaveData) {
  const salin = JSON.parse(JSON.stringify(s)) as SaveData;
  salin.simpanPada = new Date().toISOString();
  const lama = localStorage.getItem(K_SAVE);
  if (lama) {
    try {
      localStorage.setItem(K_BAK, lama);
    } catch {
      /* abaikan */
    }
  }
  return tulis(K_SAVE, salin);
}

export type IsiSlot = { waktu: string; data: SaveData } | null;

export function muatSlot(): IsiSlot[] {
  const raw = baca(K_SLOT);
  const out: IsiSlot[] = Array.from({ length: 10 }, () => null);
  if (!Array.isArray(raw)) return out;
  for (let i = 0; i < 10; i++) {
    const sl = raw[i];
    if (!sl || typeof sl !== "object") continue;
    const data = bersihkan((sl as { data?: unknown }).data);
    const waktu = typeof (sl as { waktu?: unknown }).waktu === "string" ? (sl as { waktu: string }).waktu : "";
    if (data) out[i] = { waktu, data };
  }
  return out;
}

export function simpanSlot(i: number, s: SaveData) {
  const semua = muatSlot();
  const data = bersihkan(JSON.parse(JSON.stringify(s)));
  if (!data) return false;
  data.simpanPada = new Date().toISOString();
  semua[i] = { waktu: data.simpanPada, data };
  return tulis(K_SLOT, semua);
}

export function waktuLokal(iso: string) {
  if (!iso) return "-";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleString("id-ID");
}
