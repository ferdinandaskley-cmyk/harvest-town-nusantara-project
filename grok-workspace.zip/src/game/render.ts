import { BAJU, HEWAN, IKAN, ITEM, NAMA_ALAT, NAMA_BAJU, RESEP, TANAMAN_MAP, namaMusim, namaMusimPendek } from "./data";
import { NPC_MAP } from "./npc";
import { CW, bungkus, lebar, teks, teksBayang } from "./font";
import {
  ALAT,
  CHEAT_DAFTAR,
  FESTIVAL,
  MUSIM,
  PETAS,
  STAMINA_MAX,
  ambil,
  festivalPada,
  hargaJual,
  hatiNpc,
  jamLabel,
  jumlahCurang,
  kasihHewan,
  kapasitasAir,
  levelAlat,
  namaItem,
  rp,
  tahap,
  tujuanCerita,
} from "./logic";
import { petaLuar } from "./maps";
import type { Cfg, Dialog, FloatTeks, Hot, Modal, Orang, Partikel, Plot, SaveData } from "./types";

export const VW = 320;
export const VH = 240;

export type Tampilan = {
  layar: "judul" | "nama" | "main";
  waktu: number;
  save: SaveData | null;
  cfg: Cfg;
  modal: Modal | null;
  dialog: Dialog | null;
  orang: Orang[];
  partikel: Partikel[];
  float: FloatTeks[];
  kamX: number;
  kamY: number;
  guncang: number;
  menuIdx: number;
  namaBuf: string;
  bajuPilih: number;
  siap: { jenis: "benih" | "pupuk"; id: string } | null;
  toast: string;
  toastUmur: number;
  judulPeta: string;
  judulUmur: number;
  hujan: { x: number; y: number }[];
  tambang: string[][] | null;
  lantai: number;
  hots: Hot[];
  lahan: Record<string, Plot>;
  perintah: (kode: string, n?: number) => void;
  ketik: (ch: string) => void;
};

const MENU = [
  ["Mulai Permainan", "nama"],
  ["Lanjutkan Permainan", "lanjut"],
  ["Muat Game", "muat"],
  ["Pengaturan", "atur"],
  ["Load State", "slotmuat"],
  ["Cheat", "cheat"],
  ["Kredit", "kredit"],
];

function hot(g: Tampilan, x: number, y: number, w: number, h: number, kode: string, n?: number) {
  g.hots.push({ x, y, w, h, kode, n });
}

function panel(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.fillStyle = "#2a1a12";
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = "#e6c878";
  ctx.fillRect(x, y, w, 2);
  ctx.fillRect(x, y + h - 2, w, 2);
  ctx.fillRect(x, y, 2, h);
  ctx.fillRect(x + w - 2, y, 2, h);
  ctx.fillStyle = "#6b3a22";
  ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
}

function rumputWarna(musim: string, v: number) {
  const pal =
    musim === "kemarau"
      ? ["#8a8a32", "#9aa03c", "#6e7028"]
      : musim === "panen"
        ? ["#c4a044", "#d4b45a", "#a88830"]
        : musim === "bunga"
          ? ["#3a9a48", "#4cb85a", "#2e8438"]
          : ["#2f7a38", "#3c9144", "#267033"];
  return pal[Math.abs(v) % 3];
}

function gambarUbin(ctx: CanvasRenderingContext2D, ch: string, px: number, py: number, musim: string, tx: number, ty: number, waktu: number) {
  const h = (tx * 13 + ty * 7) >>> 0;
  if (ch === "g" || ch === "G" || ch === "*") {
    ctx.fillStyle = rumputWarna(musim, h);
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = musim === "panen" ? "#8a6820" : "#1e5a28";
    ctx.fillRect(px + (h % 10), py + ((h >> 3) % 10), 2, 2);
    if (ch === "G") {
      ctx.fillStyle = "#1d6a30";
      ctx.fillRect(px + 3, py + 2, 2, 8);
      ctx.fillRect(px + 8, py + 4, 2, 7);
      ctx.fillRect(px + 12, py + 3, 2, 6);
    }
    if (ch === "*" || (musim === "bunga" && h % 6 === 0)) {
      ctx.fillStyle = musim === "bunga" ? "#e86aa0" : "#e6d35a";
      ctx.fillRect(px + 6, py + 6, 2, 2);
      ctx.fillStyle = "#3a8a32";
      ctx.fillRect(px + 6, py + 8, 2, 3);
    }
    return;
  }
  if (ch === "d" || ch === "s") {
    ctx.fillStyle = ch === "s" ? "#8a5a32" : "#c49a62";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = ch === "s" ? "#6b4424" : "#a07848";
    ctx.fillRect(px + (h % 8), py + 4, 3, 2);
    ctx.fillRect(px + 8, py + (h % 6), 4, 2);
    return;
  }
  if (ch === "=") {
    ctx.fillStyle = "#6aaa48";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#3a7a28";
    for (let i = 0; i < 4; i++) ctx.fillRect(px + 2 + i * 4, py + 4, 2, 8);
    return;
  }
  if (ch === "n") {
    ctx.fillStyle = "#e6d39a";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#c9b07a";
    ctx.fillRect(px + (h % 9), py + 3, 2, 2);
    ctx.fillRect(px + 11, py + 10, 3, 2);
    return;
  }
  if (ch === "w" || ch === "W") {
    const laut = ch === "W";
    ctx.fillStyle = laut ? "#2a6ea8" : "#3c8ec4";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = laut ? "#4aa0d0" : "#7ec8ea";
    const go = Math.floor(waktu * 3 + tx) % 8;
    ctx.fillRect(px + go, py + 4, 6, 2);
    ctx.fillRect(px + ((go + 4) % 12), py + 10, 5, 2);
    return;
  }
  if (ch === "~" || ch === "." || ch === ",") {
    ctx.fillStyle = ch === "," ? "#a08058" : ch === "." ? "#c4a06a" : "#8a5a32";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#6b4428";
    ctx.fillRect(px, py + 4, 16, 1);
    ctx.fillRect(px, py + 10, 16, 1);
    ctx.fillRect(px + 6, py, 1, 16);
    return;
  }
  if (ch === "o") {
    ctx.fillStyle = "#c4543a";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#8e3424";
    ctx.fillRect(px, py + 12, 16, 4);
    ctx.fillStyle = "#e07048";
    ctx.fillRect(px + 2, py + 3, 5, 2);
    return;
  }
  if (ch === "h" || ch === "#") {
    ctx.fillStyle = ch === "#" ? "#6b4a32" : "#e6d2a8";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = ch === "#" ? "#4a3222" : "#c4a574";
    ctx.fillRect(px, py + 14, 16, 2);
    if (h % 3 === 0 && ch === "h") {
      ctx.fillStyle = "#87c4e0";
      ctx.fillRect(px + 5, py + 4, 6, 5);
      ctx.fillStyle = "#2a1c14";
      ctx.fillRect(px + 7, py + 4, 1, 5);
    }
    return;
  }
  if (ch === "+") {
    ctx.fillStyle = "#6b3a22";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#c48a48";
    ctx.fillRect(px + 3, py + 2, 10, 14);
    ctx.fillStyle = "#e6c878";
    ctx.fillRect(px + 10, py + 8, 2, 2);
    return;
  }
  if (ch === "f") {
    ctx.fillStyle = rumputWarna(musim, h);
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#d8c090";
    ctx.fillRect(px + 2, py + 2, 3, 12);
    ctx.fillRect(px + 11, py + 2, 3, 12);
    ctx.fillStyle = "#8a6840";
    ctx.fillRect(px, py + 4, 16, 2);
    ctx.fillRect(px, py + 9, 16, 2);
    return;
  }
  if (ch === "t") {
    ctx.fillStyle = rumputWarna(musim, h);
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#6b4424";
    ctx.fillRect(px + 6, py + 8, 4, 8);
    ctx.fillStyle = "#1f7a3a";
    ctx.fillRect(px + 2, py, 12, 10);
    ctx.fillStyle = "#3cb85a";
    ctx.fillRect(px + 4, py + 2, 4, 4);
    return;
  }
  if (ch === "r" || ch === "m" || ch === "U" || ch === "X") {
    ctx.fillStyle = ch === "U" ? "#6a646c" : "#7a736c";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#4a4644";
    ctx.fillRect(px, py + 12, 16, 4);
    ctx.fillStyle = ch === "U" ? "#d8c878" : "#9a948c";
    ctx.fillRect(px + 3, py + 4, 4, 3);
    if (ch === "m") {
      ctx.fillStyle = "#5a6460";
      ctx.fillRect(px + 4, py + 2, 8, 6);
    }
    return;
  }
  if (ch === "u" || ch === "l" || ch === "L") {
    ctx.fillStyle = "#3a342c";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#2a241e";
    ctx.fillRect(px + 2, py + 8, 3, 2);
    if (ch === "l" || ch === "L") {
      ctx.fillStyle = "#c4a06a";
      ctx.fillRect(px + 6, py + 2, 4, 12);
      ctx.fillRect(px + 4, py + (ch === "L" ? 2 : 10), 8, 2);
    }
    return;
  }
  if (ch === "E") {
    ctx.fillStyle = rumputWarna(musim, h);
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#8a8a92";
    ctx.fillRect(px + 2, py + 2, 12, 12);
    ctx.fillStyle = "#3c8ec4";
    ctx.fillRect(px + 4, py + 4, 8, 8);
    return;
  }
  if (ch === "B") {
    ctx.fillStyle = "#c49a62";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#8a5a32";
    ctx.fillRect(px + 2, py + 4, 12, 10);
    ctx.fillStyle = "#e6c878";
    ctx.fillRect(px + 4, py + 6, 8, 3);
    return;
  }
  if (ch === "b") {
    ctx.fillStyle = "#c4a06a";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#f2efe6";
    ctx.fillRect(px + 1, py + 3, 14, 8);
    ctx.fillStyle = "#c4473a";
    ctx.fillRect(px + 1, py + 8, 14, 5);
    return;
  }
  if (ch === "C") {
    ctx.fillStyle = "#c4a06a";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#6b3a22";
    ctx.fillRect(px + 2, py + 4, 12, 9);
    ctx.fillStyle = "#e6c878";
    ctx.fillRect(px + 6, py + 7, 4, 2);
    return;
  }
  if (ch === "K" || ch === "V") {
    ctx.fillStyle = ch === "V" ? "#a08058" : "#c4a06a";
    ctx.fillRect(px, py, 16, 16);
    ctx.fillStyle = "#6b4428";
    ctx.fillRect(px + 1, py + 6, 14, 8);
    ctx.fillStyle = ch === "V" ? "#e6d39a" : "#8a5a32";
    ctx.fillRect(px + 3, py + 2, 10, 5);
    return;
  }
  ctx.fillStyle = "#222";
  ctx.fillRect(px, py, 16, 16);
}

function gambarTanaman(ctx: CanvasRenderingContext2D, px: number, py: number, p: Plot, waktu: number) {
  if (!p.cangkul && !p.tanaman) return;
  if (p.cangkul) {
    ctx.fillStyle = p.siram ? "#4a3420" : "#6b4428";
    ctx.fillRect(px + 1, py + 1, 14, 14);
    ctx.fillStyle = "#3a2418";
    ctx.fillRect(px + 2, py + 6, 12, 1);
    ctx.fillRect(px + 7, py + 2, 1, 12);
  }
  if (!p.tanaman) return;
  const def = TANAMAN_MAP[p.tanaman];
  const st = tahap(p);
  const warna = p.layu > 0 ? "#8a7040" : (def?.warna ?? "#3aaa48");
  ctx.fillStyle = "#2e6a30";
  if (st <= 0) {
    ctx.fillStyle = warna;
    ctx.fillRect(px + 6, py + 8, 2, 2);
    ctx.fillRect(px + 9, py + 10, 2, 2);
    return;
  }
  if (st === 1) {
    ctx.fillRect(px + 7, py + 7, 2, 6);
    ctx.fillStyle = warna;
    ctx.fillRect(px + 5, py + 6, 3, 2);
    return;
  }
  ctx.fillRect(px + 7, py + 6, 2, 8);
  ctx.fillStyle = warna;
  ctx.fillRect(px + 4, py + 4, 8, 6);
  if (st === 3) {
    ctx.fillRect(px + 3, py + 3, 3, 3);
    ctx.fillRect(px + 10, py + 5, 3, 3);
    if (Math.floor(waktu * 4) % 2 === 0) {
      ctx.fillStyle = "#fff6c8";
      ctx.fillRect(px + 12, py + 2, 2, 2);
    }
  }
}

function orang(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  o: { rambut: string; baju: string; kulit: string; topi: string; arah: string; jalan: boolean },
  waktu: number,
  kecil = false,
) {
  const bob = o.jalan && Math.floor(waktu * 8) % 2 ? 1 : 0;
  const sc = kecil ? 0.72 : 1;
  ctx.save();
  ctx.translate(sx, sy);
  ctx.scale(sc, sc);
  ctx.fillStyle = "rgba(0,0,0,.28)";
  ctx.fillRect(-5, -1, 10, 3);
  const flip = o.arah === "kiri";
  if (flip) ctx.scale(-1, 1);
  ctx.fillStyle = "#2a1c14";
  ctx.fillRect(-5, -18 + bob, 10, 16);
  ctx.fillStyle = o.baju;
  ctx.fillRect(-4, -17 + bob, 8, 9);
  ctx.fillStyle = "#3a2a22";
  ctx.fillRect(-4, -8 + bob, 3, 5);
  ctx.fillRect(1, -8 + (o.jalan ? -bob : bob), 3, 5);
  ctx.fillStyle = o.kulit;
  ctx.fillRect(-4, -26 + bob, 8, 8);
  ctx.fillStyle = o.rambut;
  if (o.arah === "atas") ctx.fillRect(-4, -28 + bob, 8, 10);
  else {
    ctx.fillRect(-4, -28 + bob, 8, 4);
    ctx.fillRect(-5, -26 + bob, 2, 5);
    ctx.fillRect(3, -26 + bob, 2, 5);
  }
  if (o.arah !== "atas") {
    ctx.fillStyle = "#2a1c14";
    ctx.fillRect(-2, -23 + bob, 1, 2);
    ctx.fillRect(1, -23 + bob, 1, 2);
  }
  if (o.topi === "caping") {
    ctx.fillStyle = "#e6c35a";
    ctx.fillRect(-6, -29 + bob, 12, 2);
    ctx.fillRect(-3, -31 + bob, 6, 2);
  } else if (o.topi === "peci") {
    ctx.fillStyle = "#2a241c";
    ctx.fillRect(-4, -30 + bob, 8, 3);
  } else if (o.topi === "bandana") {
    ctx.fillStyle = "#c4473a";
    ctx.fillRect(-4, -28 + bob, 8, 2);
  } else if (o.topi === "kembang") {
    ctx.fillStyle = "#e86aa0";
    ctx.fillRect(2, -29 + bob, 3, 3);
  }
  ctx.restore();
}

function gambarLangit(ctx: CanvasRenderingContext2D, waktu: number) {
  for (let y = 0; y < 120; y++) {
    const t = y / 120;
    const r = 90 + t * 40;
    const g = 170 - t * 30;
    const b = 220 - t * 20;
    ctx.fillStyle = "rgb(" + (r | 0) + "," + (g | 0) + "," + (b | 0) + ")";
    ctx.fillRect(0, y, VW, 1);
  }
  const sun = 40 + Math.sin(waktu * 0.4) * 4;
  ctx.fillStyle = "#ffe28a";
  ctx.fillRect(250, sun, 22, 22);
  ctx.fillStyle = "#6a8a58";
  ctx.beginPath();
  ctx.moveTo(0, 120);
  ctx.lineTo(40, 78);
  ctx.lineTo(90, 120);
  ctx.lineTo(150, 70);
  ctx.lineTo(220, 118);
  ctx.lineTo(280, 84);
  ctx.lineTo(320, 120);
  ctx.fill();
  ctx.fillStyle = "#3f9d45";
  ctx.fillRect(0, 120, VW, 120);
  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = i % 2 ? "#2f7a38" : "#c4a044";
    ctx.fillRect(10 + i * 38, 150, 30, 18);
  }
  ctx.fillStyle = "#e6d2a8";
  ctx.fillRect(36, 132, 28, 22);
  ctx.fillStyle = "#c4543a";
  ctx.fillRect(30, 120, 40, 14);
  ctx.fillStyle = "#e6d2a8";
  ctx.fillRect(230, 136, 34, 24);
  ctx.fillStyle = "#c4543a";
  ctx.fillRect(222, 122, 50, 16);
}

export function gambar(ctx: CanvasRenderingContext2D, g: Tampilan) {
  g.hots.length = 0;
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = "#10160f";
  ctx.fillRect(0, 0, VW, VH);
  ctx.save();
  if (g.guncang > 0) ctx.translate(((Math.sin(g.waktu * 40) * g.guncang) | 0), 0);
  if (g.layar === "judul" || g.layar === "nama") gambarJudul(ctx, g);
  else if (g.save) gambarDunia(ctx, g, g.save);
  if (g.dialog && g.save) gambarDialog(ctx, g);
  if (g.modal) gambarModal(ctx, g);
  if (g.toastUmur > 0 && g.toast) {
    const w = Math.min(300, lebar(g.toast) + 12);
    panel(ctx, (VW - w) / 2, 210, w, 22);
    teks(ctx, g.toast.slice(0, 48), (VW - w) / 2 + 6, 214, "#f3e2c2");
  }
  ctx.restore();
}

function gambarJudul(ctx: CanvasRenderingContext2D, g: Tampilan) {
  gambarLangit(ctx, g.waktu);
  if (g.layar === "nama") {
    gambarNama(ctx, g);
    return;
  }
  if (g.modal) return;
  panel(ctx, 48, 18, 224, 58);
  teksBayang(ctx, "HARVEST NUSANTARA", 56, 26, "#e6b34d", 1);
  teks(ctx, "KEHIDUPAN DESA", 92, 42, "#f3e2c2");
  teks(ctx, "Desa Sukamaju", 104, 56, "#e6c878");
  MENU.forEach((m, i) => {
    const y = 86 + i * 18;
    const aktif = g.menuIdx === i;
    if (aktif) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(70, y - 2, 180, 16);
    }
    teks(ctx, m[0], 78, y, aktif ? "#2a1a12" : "#f3e2c2");
    hot(g, 70, y - 2, 180, 16, "menu", i);
  });
}

function gambarNama(ctx: CanvasRenderingContext2D, g: Tampilan) {
  panel(ctx, 16, 8, 288, 224);
  teksBayang(ctx, "Siapa namamu?", 24, 16, "#e6b34d");
  ctx.fillStyle = "#1a120c";
  ctx.fillRect(24, 32, 180, 16);
  teks(ctx, (g.namaBuf || "...") + (Math.floor(g.waktu * 2) % 2 ? "_" : ""), 28, 36, "#f3e2c2");
  const baris = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];
  baris.forEach((b, ri) => {
    for (let i = 0; i < b.length; i++) {
      const x = 24 + i * 18 + (ri === 1 ? 8 : ri === 2 ? 20 : 0);
      const y = 56 + ri * 20;
      ctx.fillStyle = "#3a2418";
      ctx.fillRect(x, y, 16, 16);
      teks(ctx, b[i], x + 5, y + 4, "#f3e2c2");
      hot(g, x, y, 16, 16, "huruf", b.charCodeAt(i));
    }
  });
  tombol(ctx, g, 24, 120, 52, 16, "Spasi", "spasi");
  tombol(ctx, g, 82, 120, 52, 16, "Hapus", "hapus");
  teks(ctx, "Warna baju", 24, 146, "#e6c878");
  BAJU.forEach((warna, i) => {
    const x = 24 + i * 70;
    ctx.fillStyle = g.bajuPilih === i ? "#e6b34d" : "#1a120c";
    ctx.fillRect(x, 160, 64, 28);
    ctx.fillStyle = warna;
    ctx.fillRect(x + 4, 164, 12, 12);
    teks(ctx, NAMA_BAJU[i].split(" ")[0], x + 18, 168, "#f3e2c2");
    hot(g, x, 160, 64, 28, "baju", i);
  });
  tombol(ctx, g, 24, 198, 90, 18, "Selesai", "selesaiNama");
  tombol(ctx, g, 130, 198, 80, 18, "Kembali", "judul");
}

function tombol(ctx: CanvasRenderingContext2D, g: Tampilan, x: number, y: number, w: number, h: number, label: string, kode: string, n?: number, aktif = false) {
  ctx.fillStyle = aktif ? "#e6b34d" : "#1a120c";
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = "#e6c878";
  ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
  teks(ctx, label, x + 4, y + 4, aktif ? "#2a1a12" : "#f3e2c2");
  hot(g, x, y, w, h, kode, n);
}

function gambarDunia(ctx: CanvasRenderingContext2D, g: Tampilan, s: SaveData) {
  const peta = s.map === "tambang" ? null : PETAS[s.map];
  const tiles = s.map === "tambang" && g.tambang ? g.tambang : peta?.tiles;
  if (!tiles) return;
  const musim = s.musim;
  const x0 = Math.max(0, Math.floor(g.kamX / 16) - 1);
  const y0 = Math.max(0, Math.floor(g.kamY / 16) - 1);
  const x1 = Math.min(tiles[0].length, x0 + 23);
  const y1 = Math.min(tiles.length, y0 + 18);
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      let ch = tiles[y][x];
      if (ch === "G" && s.rumput.includes(s.map + ":" + x + "," + y)) ch = "g";
      if (ch === "*" && s.petik.includes(s.map + ":" + x + "," + y)) ch = petaLuar(s.map) && s.map === "pantai" ? "n" : "g";
      gambarUbin(ctx, ch, Math.round(x * 16 - g.kamX), Math.round(y * 16 - g.kamY), musim, x, y, g.waktu);
      if (s.map === "ladang") {
        const plot = g.lahan[x + "," + y];
        if (plot) gambarTanaman(ctx, Math.round(x * 16 - g.kamX), Math.round(y * 16 - g.kamY), plot, g.waktu);
      }
    }
  }
  if (s.map === "rumah") {
    if (s.dekor.includes("tikar")) {
      ctx.fillStyle = "#8a3030";
      ctx.fillRect(Math.round(5 * 16 - g.kamX), Math.round(6 * 16 - g.kamY), 32, 16);
    }
    if (s.dekor.includes("vas")) {
      ctx.fillStyle = "#c47a4a";
      ctx.fillRect(Math.round(13 * 16 - g.kamX) + 4, Math.round(5 * 16 - g.kamY), 8, 10);
    }
    if (s.dekor.includes("lampu")) {
      ctx.fillStyle = "#ffe28a";
      ctx.fillRect(Math.round(8 * 16 - g.kamX) + 6, Math.round(3 * 16 - g.kamY), 4, 6);
    }
    if (s.dekor.includes("lukisan") || s.dekor.includes("bendera")) {
      ctx.fillStyle = s.dekor.includes("bendera") ? "#c4473a" : "#3a6ea8";
      ctx.fillRect(Math.round(2 * 16 - g.kamX), Math.round(5 * 16 - g.kamY), 14, 10);
    }
  }
  type Spr = { y: number; go: () => void };
  const spr: Spr[] = [];
  spr.push({
    y: s.y,
    go: () =>
      orang(
        ctx,
        Math.round(s.x - g.kamX),
        Math.round(s.y - g.kamY),
        { rambut: "#3a2418", baju: BAJU[s.baju] ?? BAJU[0], kulit: "#f0c29a", topi: "caping", arah: s.arah, jalan: true },
        g.waktu,
      ),
  });
  for (const o of g.orang) {
    if (o.map !== s.map) continue;
    spr.push({
      y: o.y,
      go: () => orang(ctx, Math.round(o.x - g.kamX), Math.round(o.y - g.kamY), o, g.waktu, !!o.kecil),
    });
  }
  if (s.anak && s.map === "rumah") {
    const a = PETAS.rumah.jangkar.anak;
    spr.push({
      y: a.y * 16 + 8,
      go: () =>
        orang(
          ctx,
          Math.round(a.x * 16 + 8 - g.kamX),
          Math.round(a.y * 16 + 8 - g.kamY),
          { rambut: "#3a2418", baju: "#e6c35a", kulit: "#f0c29a", topi: "", arah: "bawah", jalan: false },
          g.waktu,
          true,
        ),
    });
  }
  if (s.map === "kandangAyam" || s.map === "kandangBesar") {
    const daftar = s.hewan.filter((h) => HEWAN[h.jenis]?.kandang === (s.map === "kandangAyam" ? "ayam" : "besar"));
    const pos =
      s.map === "kandangAyam"
        ? [
            [3, 4],
            [6, 4],
            [9, 4],
            [11, 4],
            [3, 7],
            [6, 7],
            [9, 7],
            [11, 7],
          ]
        : [
            [3, 4],
            [7, 4],
            [11, 4],
            [3, 7],
            [7, 7],
            [11, 7],
            [5, 8],
          ];
    daftar.forEach((h, i) => {
      const p = pos[i % pos.length];
      const px = p[0] * 16 + 8;
      const py = p[1] * 16 + 10;
      spr.push({
        y: py,
        go: () => gambarHewan(ctx, Math.round(px - g.kamX), Math.round(py - g.kamY), h.jenis, h.sakit, g.waktu),
      });
    });
  }
  spr.sort((a, b) => a.y - b.y);
  for (const spt of spr) spt.go();
  for (const p of g.partikel) {
    ctx.globalAlpha = Math.max(0, p.umur);
    ctx.fillStyle = p.warna;
    ctx.fillRect(Math.round(p.x - g.kamX), Math.round(p.y - g.kamY), 2, 2);
    ctx.globalAlpha = 1;
  }
  for (const f of g.float) {
    teksBayang(ctx, f.teks, Math.round(f.x - g.kamX), Math.round(f.y - g.kamY), f.warna);
  }
  if (petaLuar(s.map)) {
    const malam = s.jam >= 19 || s.jam < 5;
    const senja = (s.jam >= 17 && s.jam < 19) || (s.jam >= 5 && s.jam < 7);
    if (malam) {
      ctx.fillStyle = "rgba(8,12,28,.45)";
      ctx.fillRect(0, 0, VW, VH);
    } else if (senja) {
      ctx.fillStyle = "rgba(180,80,30,.12)";
      ctx.fillRect(0, 0, VW, VH);
    }
    if (s.cuaca === "hujan") {
      ctx.strokeStyle = "rgba(210,230,255,.7)";
      ctx.lineWidth = 1;
      for (const r of g.hujan) {
        ctx.beginPath();
        ctx.moveTo(r.x, r.y);
        ctx.lineTo(r.x - 2, r.y + 6);
        ctx.stroke();
      }
    }
    if (s.cuaca === "berawan") {
      ctx.fillStyle = "rgba(80,90,100,.12)";
      ctx.fillRect(0, 0, VW, VH);
    }
  } else if (s.map === "tambang") {
    ctx.fillStyle = "rgba(0,0,0,.28)";
    ctx.fillRect(0, 0, VW, VH);
  }
  gambarHud(ctx, g, s);
  if (g.judulUmur > 0) {
    const label = (peta?.nama ?? "Tambang Wijaya lantai " + g.lantai);
    panel(ctx, 70, 28, 180, 18);
    teks(ctx, label.slice(0, 28), 78, 32, "#f3e2c2");
  }
}

function gambarHewan(ctx: CanvasRenderingContext2D, x: number, y: number, jenis: string, sakit: boolean, waktu: number) {
  const bob = Math.floor(waktu * 4) % 2;
  ctx.fillStyle = "rgba(0,0,0,.25)";
  ctx.fillRect(x - 6, y - 1, 12, 3);
  if (jenis === "ayam" || jenis === "bebek") {
    ctx.fillStyle = sakit ? "#8a8070" : HEWAN[jenis].warna;
    ctx.fillRect(x - 5, y - 8 - bob, 10, 7);
    ctx.fillStyle = jenis === "bebek" ? "#e07020" : "#e24b3a";
    ctx.fillRect(x + 4, y - 7 - bob, 3, 2);
    ctx.fillStyle = "#e24b3a";
    ctx.fillRect(x - 2, y - 11 - bob, 3, 2);
    ctx.fillStyle = "#2a1c14";
    ctx.fillRect(x - 3, y - 2, 2, 3);
    ctx.fillRect(x + 2, y - 2, 2, 3);
    return;
  }
  ctx.fillStyle = sakit ? "#8a7868" : HEWAN[jenis].warna;
  ctx.fillRect(x - 8, y - 12, 16, 10);
  ctx.fillRect(x + 6, y - 16, 6, 6);
  ctx.fillStyle = "#2a1c14";
  ctx.fillRect(x - 6, y - 2, 2, 4);
  ctx.fillRect(x + 4, y - 2, 2, 4);
  if (jenis === "sapi") {
    ctx.fillStyle = "#5a4034";
    ctx.fillRect(x - 2, y - 10, 3, 3);
  }
  if (jenis === "domba") {
    ctx.fillStyle = "#fff";
    ctx.fillRect(x - 7, y - 14, 12, 6);
  }
}

function gambarHud(ctx: CanvasRenderingContext2D, g: Tampilan, s: SaveData) {
  ctx.fillStyle = "rgba(16,12,8,.72)";
  ctx.fillRect(0, 0, VW, 22);
  const jam = jamLabel(s.jam, s.menit);
  teks(ctx, "H" + s.hari + " " + namaMusimPendek(s.musim), 4, 2, "#f3e2c2");
  teks(ctx, "Th" + s.tahun + " " + jam, 4, 11, "#e6c878");
  const uang = jumlahCurang(g.cfg) && g.cfg.cheats.uang ? "Uang bebas" : rp(s.uang);
  teks(ctx, uang, 150, 2, "#e6b34d");
  const sta = g.cfg.cheats.stamina ? STAMINA_MAX : s.stamina;
  ctx.fillStyle = "#1a120c";
  ctx.fillRect(150, 12, 52, 6);
  ctx.fillStyle = sta < 25 ? "#c4473a" : "#3f9d45";
  ctx.fillRect(150, 12, Math.max(0, Math.min(52, (sta / STAMINA_MAX) * 52)), 6);
  const alat = NAMA_ALAT[s.alat] + (levelAlat(s, g.cfg, s.alat) > 1 ? " +" + (levelAlat(s, g.cfg, s.alat) - 1) : "");
  teks(ctx, alat, 208, 2, "#f3e2c2");
  const air = g.cfg.cheats.air ? "Air bebas" : "Air " + s.air;
  teks(ctx, air, 208, 11, "#9ad0ea");
  const ncur = jumlahCurang(g.cfg);
  if (ncur > 0) teks(ctx, "Curang " + ncur, 268, 11, "#e6b34d");
  if (g.siap) teks(ctx, "Siap: " + namaItem(g.siap.id).slice(0, 16), 4, 24, "#e6b34d");
  ALAT.forEach((a, i) => {
    const x = 4 + i * 36;
    const y = 222;
    const aktif = s.alat === a;
    ctx.fillStyle = aktif ? "#e6b34d" : "rgba(20,12,8,.75)";
    ctx.fillRect(x, y, 34, 16);
    teks(ctx, NAMA_ALAT[a].slice(0, 5), x + 2, y + 4, aktif ? "#2a1a12" : "#f3e2c2");
    hot(g, x, y, 34, 16, "alatpilih", i);
  });
}

function gambarDialog(ctx: CanvasRenderingContext2D, g: Tampilan) {
  const d = g.dialog!;
  panel(ctx, 8, 168, 304, 64);
  ctx.fillStyle = "#1a120c";
  ctx.fillRect(14, 174, 28, 28);
  ctx.fillStyle = d.warna || "#c4473a";
  ctx.fillRect(18, 186, 20, 12);
  ctx.fillStyle = "#f0c29a";
  ctx.fillRect(20, 178, 16, 10);
  teks(ctx, d.nama.slice(0, 18), 48, 174, "#e6b34d");
  const potong = bungkus(d.baris[d.i] ?? "", 40);
  potong.slice(0, 3).forEach((b, i) => teks(ctx, b, 48, 186 + i * 10, "#f3e2c2"));
  if (Math.floor(g.waktu * 2) % 2 === 0) teks(ctx, "v", 290, 214, "#e6c878");
  hot(g, 8, 168, 304, 64, "dialog");
}

function gambarModal(ctx: CanvasRenderingContext2D, g: Tampilan) {
  const m = g.modal!;
  if (m.t === "teks") {
    panel(ctx, 16, 16, 288, 200);
    teksBayang(ctx, m.judul, 24, 24, "#e6b34d");
    m.baris.slice(0, 12).forEach((b, i) => {
      bungkus(b, 44).slice(0, 2).forEach((l, k) => teks(ctx, l, 24, 42 + i * 12 + k * 10, "#f3e2c2"));
    });
    tombol(ctx, g, 220, 190, 70, 16, "Tutup", "tutup");
    return;
  }
  if (m.t === "ya") {
    panel(ctx, 30, 70, 260, 90);
    bungkus(m.teks, 40).slice(0, 4).forEach((l, i) => teks(ctx, l, 40, 80 + i * 12, "#f3e2c2"));
    tombol(ctx, g, 50, 130, 70, 18, "Ya", "ya", undefined, m.idx === 0);
    tombol(ctx, g, 150, 130, 80, 18, "Tidak", "tidak", undefined, m.idx === 1);
    return;
  }
  if (m.t === "pilih") {
    panel(ctx, 40, 40, 240, 24 + m.opsi.length * 18);
    teks(ctx, m.judul.slice(0, 28), 48, 46, "#e6b34d");
    m.opsi.forEach((o, i) => {
      const y = 64 + i * 18;
      if (m.idx === i) {
        ctx.fillStyle = "#e6b34d";
        ctx.fillRect(48, y - 2, 220, 16);
      }
      teks(ctx, o.label.slice(0, 32), 52, y, m.idx === i ? "#2a1a12" : "#f3e2c2");
      hot(g, 48, y - 2, 220, 16, "opsi", i);
    });
    return;
  }
  if (m.t === "jeda") return gambarDaftar(ctx, g, "Menu", ["Lanjut", "Tas", "Kalender", "Catatan", "Simpan State", "Load State", "Pengaturan", "Cheat", "Ke Menu Utama"], m.idx, "jeda");
  if (m.t === "atur") return gambarAtur(ctx, g, m.idx);
  if (m.t === "cheat") return gambarCheat(ctx, g);
  if (m.t === "slot") return gambarSlot(ctx, g, m);
  if (m.t === "muat") return gambarMuat(ctx, g);
  if (m.t === "kalender") return gambarKalender(ctx, g);
  if (m.t === "catatan") return gambarCatatan(ctx, g);
  if (!g.save) return;
  if (m.t === "tas" || m.t === "hadiah") return gambarTas(ctx, g, m.t === "hadiah" ? m.idx : m.idx);
  if (m.t === "toko") return gambarToko(ctx, g, m);
  if (m.t === "peti") return gambarPeti(ctx, g, m);
  if (m.t === "hewan") return gambarHewanMenu(ctx, g, m.idx);
  if (m.t === "upgrade") return gambarUpgrade(ctx, g, m.idx);
  if (m.t === "masak") return gambarMasak(ctx, g, m.idx);
  if (m.t === "mancing") return gambarMancing(ctx, g, m);
  if (m.t === "fest") return gambarFest(ctx, g, m);
  if (m.t === "anak") return gambarAnak(ctx, g, m.nama);
}

function gambarDaftar(ctx: CanvasRenderingContext2D, g: Tampilan, judul: string, items: string[], idx: number, kode: string) {
  panel(ctx, 60, 28, 200, 28 + items.length * 18);
  teksBayang(ctx, judul, 70, 34, "#e6b34d");
  items.forEach((label, i) => {
    const y = 52 + i * 18;
    if (idx === i) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(70, y - 2, 176, 16);
    }
    teks(ctx, label, 76, y, idx === i ? "#2a1a12" : "#f3e2c2");
    hot(g, 70, y - 2, 176, 16, kode, i);
  });
}

function gambarAtur(ctx: CanvasRenderingContext2D, g: Tampilan) {
  const c = g.cfg;
  const rows = [
    "Musik " + c.musik,
    "Efek " + c.efek,
    "Musik " + (c.musikNyala ? "nyala" : "mati"),
    "Suara " + (c.efekNyala ? "nyala" : "mati"),
    "Tombol " + c.tombol,
    "Sentuh " + (c.sentuh ? "nyala" : "mati"),
    "Layar penuh " + (c.layarPenuh ? "ya" : "tidak"),
    "Bahasa Indonesia",
    "Petunjuk kontrol",
    "Kembali",
  ];
  gambarDaftar(ctx, g, "Pengaturan", rows, g.modal && g.modal.t === "atur" ? g.modal.idx : 0, "atur");
  teks(ctx, "Kiri/kanan untuk mengubah", 20, 222, "#e6c878");
}

function gambarCheat(ctx: CanvasRenderingContext2D, g: Tampilan) {
  panel(ctx, 8, 8, 304, 224);
  teksBayang(ctx, "Cheat", 16, 14, "#e6b34d");
  teks(ctx, "Aktif " + jumlahCurang(g.cfg) + "  ON/OFF", 120, 14, "#f3e2c2");
  const idx = g.modal && g.modal.t === "cheat" ? g.modal.idx : 0;
  CHEAT_DAFTAR.forEach((c, i) => {
    const y = 30 + i * 12;
    if (idx === i) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(12, y - 1, 292, 12);
    }
    const on = g.cfg.cheats[c.id];
    teks(ctx, c.nama, 16, y, idx === i ? "#2a1a12" : "#f3e2c2");
    teks(ctx, on ? "ON" : "OFF", 270, y, on ? "#3f9d45" : idx === i ? "#2a1a12" : "#e6c878");
    hot(g, 12, y - 1, 292, 12, "cheat", i);
  });
  tombol(ctx, g, 240, 214, 60, 14, "Tutup", "tutup");
}

function gambarSlot(ctx: CanvasRenderingContext2D, g: Tampilan, m: Extract<Modal, { t: "slot" }>) {
  panel(ctx, 10, 8, 300, 224);
  teksBayang(ctx, m.mode === "simpan" ? "Simpan State" : "Load State", 18, 14, "#e6b34d");
  const daftar = (g as Tampilan & { slots?: { waktu: string; ringkas: string }[] }).slots;
  for (let i = 0; i < 10; i++) {
    const y = 32 + i * 16;
    if (m.idx === i) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(16, y - 1, 286, 15);
    }
    const info = daftar?.[i];
    const label = info ? i + 1 + " " + info.ringkas : i + 1 + " Kosong";
    teks(ctx, label.slice(0, 46), 20, y, m.idx === i ? "#2a1a12" : "#f3e2c2");
    hot(g, 16, y - 1, 286, 15, "slot", i);
  }
  teks(ctx, "Z pilih  X tutup", 18, 214, "#e6c878");
}

function gambarMuat(ctx: CanvasRenderingContext2D, g: Tampilan) {
  panel(ctx, 20, 40, 280, 140);
  teksBayang(ctx, "Muat Game", 30, 50, "#e6b34d");
  const info = (g as Tampilan & { muatInfo?: string[] }).muatInfo ?? ["Belum ada simpanan.", "Tidur di kasur untuk menyimpan."];
  info.slice(0, 6).forEach((l, i) => teks(ctx, l.slice(0, 42), 30, 72 + i * 12, "#f3e2c2"));
  if (info[0] !== "Belum ada simpanan.") tombol(ctx, g, 30, 150, 70, 16, "Muat", "muatYa");
  tombol(ctx, g, 140, 150, 80, 16, "Kembali", "tutup");
}

function gambarKalender(ctx: CanvasRenderingContext2D, g: Tampilan) {
  const s = g.save;
  panel(ctx, 16, 16, 288, 200);
  teksBayang(ctx, s ? namaMusim(s.musim) + " Th " + s.tahun : "Kalender", 24, 24, "#e6b34d");
  if (!s) return;
  for (let d = 1; d <= 28; d++) {
    const col = (d - 1) % 7;
    const row = Math.floor((d - 1) / 7);
    const x = 28 + col * 38;
    const y = 48 + row * 28;
    const fest = FESTIVAL.find((f) => f.musim === s.musim && f.hari === d && !(f.id === "tahun" && s.tahun < 2));
    ctx.fillStyle = d === s.hari ? "#e6b34d" : "#1a120c";
    ctx.fillRect(x, y, 34, 22);
    teks(ctx, String(d), x + 4, y + 2, d === s.hari ? "#2a1a12" : "#f3e2c2");
    if (fest) teks(ctx, fest.nama.slice(0, 4), x + 2, y + 12, d === s.hari ? "#6b3a22" : "#e6c878");
  }
  const hariIni = festivalPada(s);
  teks(ctx, hariIni ? hariIni.nama : "Tidak ada festival hari ini", 24, 176, "#f3e2c2");
  teks(ctx, "Jam " + jamLabel(s.jam, s.menit) + "  " + (s.cuaca === "hujan" ? "Hujan" : s.cuaca === "berawan" ? "Berawan" : "Cerah"), 24, 188, "#e6c878");
  tombol(ctx, g, 220, 188, 70, 16, "Tutup", "tutup");
}

function gambarCatatan(ctx: CanvasRenderingContext2D, g: Tampilan) {
  panel(ctx, 16, 16, 288, 208);
  teksBayang(ctx, "Catatan desa", 24, 24, "#e6b34d");
  if (!g.save) return;
  tujuanCerita(g.save).forEach((t, i) => {
    teks(ctx, (t.selesai ? "v " : "- ") + t.teks, 24, 44 + i * 16, t.selesai ? "#b6e0a8" : "#f3e2c2");
  });
  teks(ctx, g.save.tamat ? "Desa sudah makmur. Hidup terus berjalan." : "Selesaikan semua untuk upacara desa.", 24, 180, "#e6c878");
  tombol(ctx, g, 220, 196, 70, 16, "Tutup", "tutup");
}

function gambarTas(ctx: CanvasRenderingContext2D, g: Tampilan, idx: number) {
  const s = g.save!;
  panel(ctx, 8, 26, 304, 190);
  teks(ctx, g.modal?.t === "hadiah" ? "Pilih hadiah" : "Tas", 16, 32, "#e6b34d");
  teks(ctx, rp(s.uang), 200, 32, "#e6b34d");
  for (let i = 0; i < 24; i++) {
    const col = i % 8;
    const row = Math.floor(i / 8);
    const x = 16 + col * 22;
    const y = 48 + row * 22;
    ctx.fillStyle = idx === i ? "#e6b34d" : "#1a120c";
    ctx.fillRect(x, y, 20, 20);
    const sl = s.tas[i];
    if (sl) {
      teks(ctx, (ITEM[sl.id]?.nama ?? "?").slice(0, 1), x + 4, y + 2, idx === i ? "#2a1a12" : "#f3e2c2");
      teks(ctx, String(sl.n), x + 2, y + 11, idx === i ? "#2a1a12" : "#e6c878");
    }
    hot(g, x, y, 20, 20, "tas", i);
  }
  const sl = s.tas[idx];
  if (sl) {
    const def = ITEM[sl.id];
    teks(ctx, (def?.nama ?? sl.id) + (sl.subur ? " subur" : "") + " x" + sl.n, 16, 120, "#f3e2c2");
    const des = bungkus(def?.deskripsi ?? "", 48);
    des.slice(0, 2).forEach((l, i) => teks(ctx, l, 16, 132 + i * 10, "#e6c878"));
    if (def?.jual) teks(ctx, "Jual " + rp(hargaJual(sl)), 16, 154, "#e6b34d");
  } else teks(ctx, "Slot kosong", 16, 124, "#f3e2c2");
  tombol(ctx, g, 16, 176, 60, 16, g.modal?.t === "hadiah" ? "Beri" : "Pakai", "tasPakai");
  tombol(ctx, g, 84, 176, 60, 16, "Buang", "tasBuang");
  tombol(ctx, g, 152, 176, 70, 16, "Tutup", "tutup");
  if (g.siap) tombol(ctx, g, 230, 176, 70, 16, "Batal", "batalSiap");
}

function gambarToko(ctx: CanvasRenderingContext2D, g: Tampilan, m: Extract<Modal, { t: "toko" }>) {
  const s = g.save!;
  panel(ctx, 8, 24, 304, 200);
  const judul = m.jenis === "benih" ? "Benih" : m.jenis === "hewan" ? "Hewan" : m.jenis === "warung" ? "Warung" : "Toko";
  teksBayang(ctx, (m.jual ? "Jual - " : "Beli - ") + judul, 16, 30, "#e6b34d");
  teks(ctx, g.cfg.cheats.uang ? "Uang bebas" : rp(s.uang), 200, 30, "#e6b34d");
  const list = daftarToko(g, m);
  const mulai = Math.max(0, Math.min(m.idx - 3, Math.max(0, list.length - 7)));
  list.slice(mulai, mulai + 7).forEach((it, i) => {
    const y = 48 + i * 16;
    const nyata = mulai + i;
    if (m.idx === nyata) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(14, y - 2, 290, 15);
    }
    teks(ctx, it.label.slice(0, 46), 18, y, m.idx === nyata ? "#2a1a12" : "#f3e2c2");
    hot(g, 14, y - 2, 290, 15, "toko", nyata);
  });
  if (!list.length) teks(ctx, "Tidak ada barang.", 18, 60, "#f3e2c2");
  tombol(ctx, g, 16, 176, 80, 16, m.jual ? "Beli" : "Jual", "tokoMode");
  tombol(ctx, g, 110, 176, 70, 16, "Pilih", "tokoYa");
  tombol(ctx, g, 200, 176, 70, 16, "Tutup", "tutup");
}

export type BarisToko = { label: string; id: string; harga: number; jenis: string };

export function daftarToko(g: Tampilan, m: Extract<Modal, { t: "toko" }>): BarisToko[] {
  const s = g.save!;
  if (m.jual) {
    const out: BarisToko[] = [];
    s.tas.forEach((sl, i) => {
      if (!sl) return;
      const h = hargaJual(sl);
      if (h <= 0) return;
      out.push({ label: namaItem(sl.id) + " x" + sl.n + " " + rp(h), id: String(i), harga: h, jenis: "jual" });
    });
    return out;
  }
  if (m.jenis === "benih") {
    const { benihToko } = requireToko();
    return benihToko(s, g.cfg).map((it) => ({
      label: it.nama + " " + rp(it.beli ?? 0),
      id: it.id,
      harga: it.beli ?? 0,
      jenis: "item",
    }));
  }
  if (m.jenis === "warung") {
    return ["nasi", "kopi", "gorengan", "sate", "esjeruk"].map((id) => ({
      label: ITEM[id].nama + " " + rp(ITEM[id].beli ?? 0),
      id,
      harga: ITEM[id].beli ?? 0,
      jenis: "item",
    }));
  }
  if (m.jenis === "hewan") {
    return Object.values(HEWAN).map((h) => {
      const kunci = h.kunci && !g.cfg.cheats.hewan;
      return {
        label: (kunci ? "(terkunci) " : "") + h.nama + " " + rp(h.harga),
        id: h.id,
        harga: h.harga,
        jenis: kunci ? "kunci" : "hewan",
      };
    });
  }
  const dasar = ["pupuk", "pakan", "obat", "cincin", "bunga", "tikar", "vas", "lampu", "lukisan"].map((id) => ({
    label: ITEM[id].nama + " " + rp(ITEM[id].beli ?? 0),
    id,
    harga: ITEM[id].beli ?? 0,
    jenis: "item",
  }));
  if (!s.punyaPancing || g.cfg.cheats.alat) dasar.unshift({ label: "Pancingan " + rp(400), id: "pancing", harga: 400, jenis: "pancing" });
  return dasar;
}

function requireToko() {
  return { benihToko: (null as unknown as typeof import("./logic")) && undefined };
}

function gambarPeti(ctx: CanvasRenderingContext2D, g: Tampilan, m: Extract<Modal, { t: "peti" }>) {
  const s = g.save!;
  const kanan = m.mode === "lemari" ? s.lemari : s.bin;
  panel(ctx, 6, 24, 308, 200);
  teks(ctx, m.mode === "lemari" ? "Lemari" : "Tong pengiriman", 14, 30, "#e6b34d");
  teks(ctx, m.sisi === 0 ? "Tas" : m.mode === "lemari" ? "Lemari" : "Tong", 200, 30, "#e6c878");
  const sumber = m.sisi === 0 ? s.tas : kanan;
  const max = Math.min(sumber.length, 18);
  for (let i = 0; i < max; i++) {
    const col = i % 6;
    const row = Math.floor(i / 6);
    const x = 16 + col * 48;
    const y = 48 + row * 28;
    ctx.fillStyle = m.idx === i ? "#e6b34d" : "#1a120c";
    ctx.fillRect(x, y, 44, 24);
    const sl = sumber[i];
    if (sl) {
      teks(ctx, namaItem(sl.id).slice(0, 6), x + 2, y + 2, m.idx === i ? "#2a1a12" : "#f3e2c2");
      teks(ctx, "x" + sl.n, x + 2, y + 12, m.idx === i ? "#2a1a12" : "#e6c878");
    }
    hot(g, x, y, 44, 24, "peti", i);
  }
  tombol(ctx, g, 16, 180, 80, 16, "Pindah", "petiPindah");
  tombol(ctx, g, 110, 180, 90, 16, m.sisi === 0 ? "Ke simpanan" : "Ke tas", "petiSisi");
  tombol(ctx, g, 214, 180, 70, 16, "Tutup", "tutup");
}

function gambarHewanMenu(ctx: CanvasRenderingContext2D, g: Tampilan, idx: number) {
  const s = g.save!;
  const jenis = s.map === "kandangAyam" ? "ayam" : "besar";
  const list = s.hewan.filter((h) => HEWAN[h.jenis]?.kandang === jenis);
  panel(ctx, 10, 24, 300, 200);
  teksBayang(ctx, jenis === "ayam" ? "Kandang unggas" : "Kandang ternak", 18, 30, "#e6b34d");
  if (!list.length) teks(ctx, "Kandang kosong. Beli hewan lewat Bima.", 18, 56, "#f3e2c2");
  list.slice(0, 6).forEach((h, i) => {
    const y = 48 + i * 18;
    if (idx === i) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(16, y - 2, 280, 16);
    }
    const status = h.sakit && !g.cfg.cheats.sakit ? "sakit" : h.kenyang ? "kenyang" : "lapar";
    teks(
      ctx,
      h.nama + " " + (h.gender === "j" ? "J" : "B") + " hati " + Math.ceil(kasihHewan(h, g.cfg) / 10) + " " + status,
      20,
      y,
      idx === i ? "#2a1a12" : "#f3e2c2",
    );
    hot(g, 16, y - 2, 280, 16, "hewan", i);
  });
  tombol(ctx, g, 16, 168, 52, 16, "Elus", "elus");
  tombol(ctx, g, 72, 168, 58, 16, "Pakan", "pakan");
  tombol(ctx, g, 134, 168, 58, 16, "Ambil", "ambilHasil");
  tombol(ctx, g, 196, 168, 52, 16, "Obat", "obat");
  tombol(ctx, g, 16, 190, 100, 16, "Kembangbiak", "biak");
  tombol(ctx, g, 130, 190, 80, 16, "Upgrade", "upgradeKandang");
  tombol(ctx, g, 220, 190, 70, 16, "Tutup", "tutup");
}

function gambarUpgrade(ctx: CanvasRenderingContext2D, g: Tampilan, idx: number) {
  const s = g.save!;
  panel(ctx, 16, 28, 288, 180);
  teksBayang(ctx, "Upgrade alat", 24, 36, "#e6b34d");
  const alat = ["cangkul", "gembor", "sabit", "palu"] as const;
  alat.forEach((a, i) => {
    const y = 56 + i * 22;
    const lv = s.levelAlat[a];
    if (idx === i) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(24, y - 2, 260, 18);
    }
    teks(ctx, NAMA_ALAT[a] + " tingkat " + lv + (lv >= 4 ? " maks" : ""), 28, y, idx === i ? "#2a1a12" : "#f3e2c2");
    hot(g, 24, y - 2, 260, 18, "upgrade", i);
  });
  teks(ctx, "Butuh uang dan bijih. Rama yang menempa.", 24, 156, "#e6c878");
  tombol(ctx, g, 24, 176, 80, 16, "Tempa", "tempa");
  tombol(ctx, g, 140, 176, 70, 16, "Tutup", "tutup");
}

function gambarMasak(ctx: CanvasRenderingContext2D, g: Tampilan, idx: number) {
  panel(ctx, 16, 28, 288, 180);
  teksBayang(ctx, "Dapur", 24, 36, "#e6b34d");
  RESEP.forEach((r, i) => {
    const y = 54 + i * 20;
    if (idx === i) {
      ctx.fillStyle = "#e6b34d";
      ctx.fillRect(24, y - 2, 260, 18);
    }
    const bahan = r.bahan.map(([id, n]) => namaItem(id) + "x" + n).join(", ");
    teks(ctx, r.nama, 28, y, idx === i ? "#2a1a12" : "#f3e2c2");
    hot(g, 24, y - 2, 260, 18, "masak", i);
    teks(ctx, bahan.slice(0, 40), 28, y + 8, idx === i ? "#6b3a22" : "#e6c878");
  });
  tombol(ctx, g, 24, 176, 80, 16, "Masak", "masakYa");
  tombol(ctx, g, 140, 176, 70, 16, "Tutup", "tutup");
}

function gambarMancing(ctx: CanvasRenderingContext2D, g: Tampilan, m: Extract<Modal, { t: "mancing" }>) {
  panel(ctx, 20, 70, 280, 90);
  teks(ctx, "Tarik saat jarum di zona hijau", 30, 78, "#f3e2c2");
  ctx.fillStyle = "#1a120c";
  ctx.fillRect(36, 100, 248, 14);
  ctx.fillStyle = "#3f9d45";
  const zw = m.lebar * 248;
  ctx.fillRect(36 + m.zona * 248 - zw / 2, 100, zw, 14);
  ctx.fillStyle = "#f3e2c2";
  ctx.fillRect(36 + m.penanda * 248 - 2, 96, 4, 22);
  teks(ctx, "Kena " + m.kena + "/3   Gagal " + m.gagal + "/3", 36, 124, "#e6c878");
  tombol(ctx, g, 36, 140, 80, 14, "Tarik", "tarik");
}

function gambarFest(ctx: CanvasRenderingContext2D, g: Tampilan, m: Extract<Modal, { t: "fest" }>) {
  panel(ctx, 16, 36, 288, 170);
  const nama =
    m.jenis === "layang"
      ? "Layang-layang"
      : m.jenis === "kuis"
        ? "Kuis kemerdekaan"
        : m.jenis === "panen"
          ? "Festival panen"
          : m.jenis === "masak"
            ? "Lomba memasak"
            : m.jenis === "ayam"
              ? "Lomba ayam"
              : m.jenis === "ternak"
                ? "Festival ternak"
                : m.jenis === "pancing"
                  ? "Lomba memancing"
                  : "Festival";
  teksBayang(ctx, nama, 24, 44, "#e6b34d");
  if (m.jenis === "layang") {
    ctx.fillStyle = "#1a120c";
    ctx.fillRect(36, 80, 248, 12);
    ctx.fillStyle = "#3f9d45";
    ctx.fillRect(36 + 100, 80, 48, 12);
    ctx.fillStyle = "#f3e2c2";
    ctx.fillRect(36 + m.penanda * 248, 76, 4, 20);
    teks(ctx, "Putaran " + (m.putaran + 1) + "/5  skor " + m.skor, 36, 104, "#f3e2c2");
    tombol(ctx, g, 36, 130, 80, 16, "Lepas", "festAksi");
  } else if (m.jenis === "kuis") {
    const { KUIS } = kuisData();
    const q = KUIS[m.fase] ?? KUIS[0];
    bungkus(q.tanya, 42).forEach((l, i) => teks(ctx, l, 28, 64 + i * 12, "#f3e2c2"));
    q.pilih.forEach((p, i) => {
      const y = 100 + i * 18;
      if (m.idx === i) {
        ctx.fillStyle = "#e6b34d";
        ctx.fillRect(28, y - 2, 240, 16);
      }
      teks(ctx, p, 34, y, m.idx === i ? "#2a1a12" : "#f3e2c2");
      hot(g, 28, y - 2, 240, 16, "festPilih", i);
    });
  } else {
    teks(ctx, "Skor sementara " + m.skor, 28, 70, "#f3e2c2");
    teks(ctx, m.fase === 0 ? "Pilih lalu mulai." : "Selesai sebentar lagi.", 28, 86, "#e6c878");
    tombol(ctx, g, 28, 120, 90, 16, "Mulai", "festAksi");
    tombol(ctx, g, 140, 120, 80, 16, "Tutup", "tutup");
  }
  if (m.jenis !== "kuis" && m.jenis !== "layang") {
    /* tombol sudah ada */
  } else tombol(ctx, g, 200, 160, 70, 16, "Tutup", "tutup");
}

function kuisData() {
  return { KUIS: [] as { tanya: string; pilih: string[]; jawab: number }[] };
}

function gambarAnak(ctx: CanvasRenderingContext2D, g: Tampilan, nama: string) {
  panel(ctx, 20, 30, 280, 180);
  teksBayang(ctx, "Nama anak", 30, 40, "#e6b34d");
  teks(ctx, "Kalian akan menyambut anak.", 30, 58, "#f3e2c2");
  ctx.fillStyle = "#1a120c";
  ctx.fillRect(30, 78, 200, 16);
  teks(ctx, nama || "...", 34, 82, "#f3e2c2");
  const b = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (let i = 0; i < b.length; i++) {
    const x = 30 + (i % 10) * 18;
    const y = 104 + Math.floor(i / 10) * 18;
    ctx.fillStyle = "#3a2418";
    ctx.fillRect(x, y, 16, 16);
    teks(ctx, b[i], x + 4, y + 4, "#f3e2c2");
    hot(g, x, y, 16, 16, "huruf", b.charCodeAt(i));
  }
  tombol(ctx, g, 30, 180, 60, 16, "Hapus", "hapus");
  tombol(ctx, g, 110, 180, 90, 16, "Selesai", "anakYa");
}

export function siapkanSlotView(
  g: Tampilan,
  slots: { waktu: string; ringkas: string }[] | null,
  muatInfo: string[] | null,
) {
  (g as Tampilan & { slots?: { waktu: string; ringkas: string }[]; muatInfo?: string[] }).slots = slots ?? undefined;
  if (muatInfo) (g as Tampilan & { muatInfo?: string[] }).muatInfo = muatInfo;
}

export function warnaNpc(id: string) {
  return NPC_MAP[id]?.baju ?? "#c4473a";
}

void ambil;
void CW;
void IKAN;
void kapasitasAir;
void hatiNpc;
