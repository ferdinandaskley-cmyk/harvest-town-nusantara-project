export const CHEAT_DAFTAR = [
  { id: "uang", nama: "Uang Tak Terbatas" },
  { id: "stamina", nama: "Stamina Tak Terbatas" },
  { id: "air", nama: "Air Tak Terbatas" },
  { id: "benih", nama: "Semua Benih Terbuka" },
  { id: "tanaman", nama: "Semua Tanaman Terbuka" },
  { id: "panen", nama: "Panen Instan" },
  { id: "tumbuh", nama: "Pertumbuhan Tanaman Instan" },
  { id: "npc", nama: "Kasih Sayang NPC Maksimal" },
  { id: "hewanHati", nama: "Kasih Sayang Hewan Maksimal" },
  { id: "hewan", nama: "Semua Hewan Terbuka" },
  { id: "alat", nama: "Semua Peralatan Maksimal" },
  { id: "area", nama: "Semua Area Terbuka" },
  { id: "ikan", nama: "Semua Ikan Terbuka" },
  { id: "sakit", nama: "Tidak Ada Hewan Sakit" },
  { id: "waktu", nama: "Waktu Berhenti" },
] as const;

export type CheatId = (typeof CHEAT_DAFTAR)[number]["id"];
export type Arah = "atas" | "bawah" | "kiri" | "kanan";
export type Musim = "hujan" | "kemarau" | "panen" | "bunga";
export type Cuaca = "cerah" | "berawan" | "hujan";
export type AlatId = "cangkul" | "gembor" | "sabit" | "palu" | "pancing";

export type Slot = { id: string; n: number; subur?: boolean };

export type Plot = {
  x: number;
  y: number;
  cangkul: boolean;
  siram: boolean;
  tanaman: string | null;
  tumbuh: number;
  layu: number;
  pupuk: boolean;
};

export type Hewan = {
  uid: number;
  jenis: string;
  nama: string;
  gender: "j" | "b";
  kasih: number;
  kenyang: boolean;
  lapar: number;
  sakit: boolean;
  siap: boolean;
  wol: number;
  umur: number;
  hamil: number;
};

export type Memori = {
  hati: number;
  bicara: boolean;
  hadiah: boolean;
  kencan: boolean;
  ev: string[];
};

export type TambangData = { lantai: number; biji: number; baris: string[] } | null;

export type SaveData = {
  version: number;
  nama: string;
  baju: number;
  uang: number;
  stamina: number;
  jam: number;
  menit: number;
  hari: number;
  musim: Musim;
  tahun: number;
  cuaca: Cuaca;
  map: string;
  x: number;
  y: number;
  arah: Arah;
  alat: AlatId;
  levelAlat: Record<AlatId, number>;
  air: number;
  punyaPancing: boolean;
  tas: (Slot | null)[];
  lemari: (Slot | null)[];
  bin: (Slot | null)[];
  lahan: Plot[];
  rumput: string[];
  petik: string[];
  hewan: Hewan[];
  kandangAyam: number;
  kandangBesar: number;
  npc: Record<string, Memori>;
  pasangan: string | null;
  tungguNikah: string | null;
  hariNikah: number;
  anak: { nama: string; umur: number } | null;
  ikan: string[];
  dekor: string[];
  flag: Record<string, boolean>;
  festSelesai: string[];
  stat: { panen: number; penghasilan: number; kenalan: string[]; festival: number };
  nextUid: number;
  pesanPagi: string[];
  adegan: "" | "surat" | "nikah" | "anak" | "tamat";
  tamat: boolean;
  simpanPada: string;
  cheats: Record<CheatId, boolean>;
  tambangData: TambangData;
};

export type Cfg = {
  musik: number;
  efek: number;
  musikNyala: boolean;
  efekNyala: boolean;
  tombol: "kecil" | "sedang" | "besar";
  layarPenuh: boolean;
  sentuh: boolean;
  cheats: Record<CheatId, boolean>;
};

export type Opsi = { label: string; kode: string; n?: number };

export type Modal =
  | { t: "pilih"; judul: string; opsi: Opsi[]; idx: number }
  | { t: "ya"; teks: string; idx: number; ya: string; tidak: string }
  | { t: "tas"; idx: number }
  | { t: "toko"; jenis: "benih" | "umum" | "warung" | "hewan"; idx: number; jual: boolean }
  | { t: "peti"; mode: "lemari" | "bin"; idx: number; sisi: 0 | 1 }
  | { t: "hewan"; idx: number }
  | { t: "upgrade"; idx: number }
  | { t: "masak"; idx: number }
  | {
      t: "mancing";
      penanda: number;
      arah: number;
      zona: number;
      zonaArah: number;
      lebar: number;
      kena: number;
      gagal: number;
      tempat: string;
      asal: string;
    }
  | {
      t: "fest";
      jenis: string;
      fase: number;
      idx: number;
      skor: number;
      penanda: number;
      arah: number;
      zona: number;
      putaran: number;
    }
  | { t: "jeda"; idx: number }
  | { t: "atur"; idx: number }
  | { t: "cheat"; idx: number }
  | { t: "slot"; mode: "simpan" | "muat"; idx: number }
  | { t: "muat" }
  | { t: "kalender" }
  | { t: "catatan" }
  | { t: "teks"; judul: string; baris: string[] }
  | { t: "hadiah"; idx: number; npc: string }
  | { t: "anak"; nama: string };

export type Dialog = {
  nama: string;
  baris: string[];
  i: number;
  warna: string;
  selesai?: string;
};

export type Hot = { x: number; y: number; w: number; h: number; kode: string; n?: number };

export type Orang = {
  id: string;
  nama: string;
  map: string;
  x: number;
  y: number;
  arah: Arah;
  jalan: boolean;
  rambut: string;
  baju: string;
  kulit: string;
  topi: string;
  kecil?: boolean;
};

export type Partikel = { x: number; y: number; vx: number; vy: number; umur: number; warna: string };
export type FloatTeks = { x: number; y: number; teks: string; umur: number; warna: string };

export const MUSIM: Musim[] = ["hujan", "kemarau", "panen", "bunga"];
export const ALAT: AlatId[] = ["cangkul", "gembor", "sabit", "palu", "pancing"];
export const UK_TAS = 24;
export const UK_LEMARI = 30;
export const UK_BIN = 12;
export const STAMINA_MAX = 100;
export const VERSI = 1;

export function cheatsKosong(): Record<CheatId, boolean> {
  const c = {} as Record<CheatId, boolean>;
  for (const x of CHEAT_DAFTAR) c[x.id] = false;
  return c;
}
